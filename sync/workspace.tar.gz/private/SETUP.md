# Application repairs — October 3, 2026

Saved and verified in Jobright: Male, Heterosexual, no disability, no LGBTQ+ identity, no veteran, sponsorship required. Local answers now record August 2023 school start, May 31, 2027 internship start, immediate/future sponsorship, CPT/OPT not requested, free-text permit dates N/A, and https://github.com/khanh-nguyen-nam. Ordinary company answers may be drafted from verified profile and resume facts.

The 5 AM automation remains active. Its morning run started but stopped at a browser consent request. Standing approval and continuation instructions now preserve specific Graphcore consent, checkpoint individual blockers, and continue other usable jobs. Mandatory browser handoffs can still occur.

## Repairs completed

- Graphcore Greenhouse successfully accepted the actual approved May 2028 PDF through its Attach file chooser. The filename is visible. No new application was submitted. The earlier file-only upload limitation is resolved for the tested Chrome profile/employer.
- Resideo Firmware Engineer I requisition 18760 was verified with a fresh email code. The portal shows Profile Received and Applied on September 30, 2026. Its expired-code blocker is cleared. No duplicate submission occurred.
- Gmail historical pagination and pending messages are complete. 323 full messages were read with no fetch errors. 97 identified historical application records were added; the tracker now has 272 rows. These are historical imports, not 97 new submissions today. The incremental completion checkpoint was preserved conservatively.
- 12 of the original 69 review items were resolved. 57 original items still lack reliable identity. After adding ambiguous messages found during the backfill, the current review queue has 139 items. Company-only receipts and unclear interview titles remain in review rather than being assigned guessed requisitions.

## Still unresolved or required only for a specific application

1. Formlabs duplicate check is resolved: signed-in MyGreenhouse application 79305919 directly links to Embedded Software Engineer requisition 7909577. It is distinct from Summer 2027 internship 8222268. The prior generic receipt is now matched. The internship remains blocked only by its term/availability wording.
2. Formlabs form wording asks about winter/spring while its posting says summer. May 31, 2027 availability is saved; an incompatible term or required hours/end date still needs a factual answer. The public GitHub portfolio and an accurate C++ RAII response have been prepared. Formlabs permits accurate AI-assisted application materials: https://careers.formlabs.com/ai-guidelines/.
3. Jobright shared education defaults to May 2027 for new-grad roles. Before internship Autofill, use the confirmed May 2028 internship plan and matching approved resume, or verified manual employer controls. The scheduled instructions enforce this distinction.
4. A question asking for an actual current country-specific work permit, citizenship, clearance, visa category or permit expiration cannot be answered from worldwide eligibility alone. CPT/OPT free-text dates remain N/A as instructed. Required date controls must be handled truthfully rather than filled with invented dates.
5. Employer-specific browser sensitive-data consent, new agreements, credentials, non-email MFA and CAPTCHA may still need a handoff. A single such blocker now checkpoints the role and permits the overnight batch to continue.

No general setup question remains for disability, LGBTQ+, orientation, gender, veteran status, GitHub or school/start dates. No emails were sent and no mailbox labels/read state were changed.

## Latest market and sign-in update
Active market is the United States for now; other markets deferred. Routine consents and matching email-code sign-in are authorized. The current MyGreenhouse agreement received a direct user confirmation in response to the disclosed blocker on October 3. Future unidentified binding agreements retain action-time confirmation requirements.

MyGreenhouse email-code sign-in is now verified. Current consent completed using the user’s direct reply to this specific blocker. No new job submission occurred.
