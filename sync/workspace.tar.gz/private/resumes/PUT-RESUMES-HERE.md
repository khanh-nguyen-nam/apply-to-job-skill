# Resume uploads

Put your current resume PDF(s) in this folder. Keep distinct versions under distinct filenames, for example `Khanh-Nguyen-Embedded.pdf` and `Khanh-Nguyen-Systems.pdf`.

Tell Codex which file(s) to use. It will read the actual documents, resolve conflicting dates, compute version hashes, and update `../resumes.json`. No file has been approved or uploaded to Jobright yet.
