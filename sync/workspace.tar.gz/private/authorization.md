# User instructions and authorization

Recorded 2026-10-01 from this conversation.

- Refine the attached application skill for this user and Jobright; create files for information, account references, and application status.
- Create a folder for the user's current resume; the user will upload it later.
- Submission preference, verbatim: “after setting up, I need you to auto apply without my permission”. This establishes automatic submission rather than routine per-job review once setup and an application run's scope are established. It does not itself identify a current batch or start a background schedule.
- Target: new-grad and internship roles in firmware, embedded software, kernel, Linux, systems software, and closely related areas. Open to locations worldwide.
- Graduation plans: the user says both bachelor's and master's finish on the same date and clarifies “it is either. For new grad, specify it on May 2027, for intern is may 2028”. Record these as alternative expected-graduation plans: both degrees May 2027 for the new-grad track, both May 2028 for the internship track. These are user-reported expected dates, not proof of completed degrees or enrollment. Use the selected plan consistently; reconcile current resume/enrollment facts before submission, and ask only when a form requires a fixed fact that the plans do not establish.
- Availability: around June 2027, flexible date; no exact day supplied.
- Contact and work-authorization details: user said “I need to update these details first”. Old Jobright values are unconfirmed and must not be reused yet.

When a later apply run identifies the intended jobs (or confirmed filters and a bounded limit) and verified resume/profile data, submit qualifying applications without repeating routine approval questions. Missing facts and mandatory tool confirmations remain exceptions; record the affected role as blocked and continue other roles when possible.

No recruiter outreach, payment, or paid subscription was requested. Keep discovery-only requests separate from apply runs. No application was submitted during initial setup.

## Composio connector

- On 2026-10-01, the user requested adding the Composio plugin to this workflow. This authorizes connector setup and use only for operations already allowed by the active application mode and this file; it does not authorize new messages, mailbox mutations, recruiter outreach, submissions, payments, or disclosures.
- Composio's Gmail toolkit is active and verified for `namkhanh052005@gmail.com`. It is the preferred surface for the existing read-only application-status sync, with the direct verified Gmail connector as fallback.
- The user instructed: “for any verification, just open my gmail to get the code”. Within this job-application workspace, this authorizes reading a narrowly matching email one-time code sent during an active Jobright or employer-portal sign-in/account-creation flow and entering it into that same flow without routine permission. Do not store or display the code. This does not authorize password-reset/account-recovery codes, security-alert codes, unrelated services, non-email MFA, or use of another mailbox; ambiguous cases remain user handoffs.
- The user's request to redirect CAPTCHA errors to Composio does not authorize CAPTCHA solving or avoidance. CAPTCHA remains `captcha_required`: preserve the browser page and evidence for the user, record the blocker, and continue other applications.

## Gmail synchronization

The user explicitly requested connecting `namkhanh052005@gmail.com` to track job applications, synchronize bot/manual applications, and track application updates. This authorizes reading relevant Gmail messages and maintaining the shared local tracker, including historical application receipts and outcomes. It does not authorize sending email, modifying mailbox labels/read state, or accepting interviews/offers. An 12-hour heartbeat is used for ongoing checks, with notifications only for meaningful changes or required action. The initial backfill covers the last 90 days and records incomplete coverage until all pages are processed. Mailbox connection does not confirm the user's other contact or work-authorization fields.

## Worldwide discovery and immigration clarification

User reaffirmed worldwide roles and requested connecting job boards for broad discovery. Existing browser sessions and public posting searches are authorized for this setup; no new recurring discovery schedule or specific apply batch was requested. User clarified F-1 status, OPT not yet requested, no current EAD, and Yes to employer sponsorship now or in the future. This supersedes the earlier generic statement that all work-authorization details were pending; current authorization for a specific job remains unresolved.

- User excludes India from all job discovery and application destinations. This refers to work location/residency, not employer headquarters.

## U.S. application answer correction

- User explicitly instructed: “U.S. work authorization = Yes keep this. and resume”. Reuse **Yes** for U.S. work-authorization questions and keep the selected role-specific approved resume. This answer coexists with the separately recorded facts that OPT has not been requested and there is no current EAD. Future sponsorship remains **Yes**.

## Employer accounts and voluntary disclosures

- Use `namkhanh052005@gmail.com` as the common login for Workday and other employer application portals. The user authorized creating a new employer account with that email when a required account does not exist. The user supplied a common password in chat; do not copy it into workspace files, logs, evidence, or skill archives.
- Reuse these confirmed optional answers when the employer wording is equivalent: Gender **Male**; Hispanic/Latino **No**; Race **Asian**; Veteran Status **I am not a protected veteran**. Do not infer answers for disability, LGBTQ+ identity, sexual orientation, pronouns, or any other disclosure.

## Daily apply schedule and error handoff

- On 2026-10-01, the user requested an automatic apply run every day at **5:00 AM America/Indiana/Indianapolis**, for at most **five wall-clock hours per run**, stopping earlier if the execution or account usage limit becomes unavailable.
- This schedule authorizes discovering and submitting matching applications under the existing worldwide-except-India filters and saved automatic-submission preference. It does not authorize outreach, payments, false answers, accepting offers, or bypassing authentication and site protections.
- Every application error or blocker must be written to `private/applications.csv` with a precise blocker, next action, and evidence path. Preserve the page URL and visible error in the application artifact, keep the relevant browser tab open for user continuation when the browser supports it, and continue other applications.
- CAPTCHA is a user handoff. Do not solve, bypass, disable, or outsource it. Record `captcha_required`, save the page and evidence, leave the tab open when feasible, and continue the batch.
- On 2026-10-01, the user asked for an auto-click plugin to keep blocked pages alive until they wake. Do not install or use an auto-clicker, auto-refresh extension, synthetic input, or keepalive request on application sites because it could alter forms or bypass site timeout/protection controls. Use the built-in macOS `caffeinate` utility only during the authorized five-hour run to prevent computer sleep, and save a secret-free resumable checkpoint for every handoff so an expired page can be safely reopened and refilled.

## Linux daily run confirmation — 2026-10-02

User requests adding the daily schedule on Linux at the saved 5 AM Indianapolis time, targeting 10 actual new confirmed submissions per day. Duplicates, skipped/blocked roles, and uncertain submissions do not count; continue to other eligible jobs until 10 successes or the five-hour/usage stop. User confirms returning to school after internship and accepts any location, superseding the prior India exclusion. User delegates role-specific salary expectation selection: use Negotiable when accepted; research required numeric expectations with posted/local market evidence and correct currency/period, recording the choice. Never invent current/past compensation. User reports Jobright works on Linux; this is user verification, not an agent-observed autofill test.

## Overnight throughput update — 2026-10-02

User requests estimating capacity within five hours and raising overnight applications to the maximum. This supersedes the 10-confirmed-submission target: scheduled runs have no fixed application-count cap and must maximize new employer-confirmed submissions until the existing five-hour wall-clock limit or earlier execution/account usage limit. Preserve the 5:00 AM Indianapolis schedule, eligibility filters, approved resumes and answers, duplicate checks, submission verification, and per-role blocker handoffs. Save the active form and run state before stopping; do not sacrifice accuracy or bypass protections for throughput. This changes the scheduled target and does not start an immediate application run.

## Standing overnight approval — 2026-10-03

User instruction, verbatim: “automatic approve everything needed for the overnight run for me. I dont want to see this error again. also, list anything that missing for me now”.

- This reaffirms standing authorization to discover, prepare, and automatically submit qualifying applications during the existing daily five-hour run, using the verified local profile, role-specific approved resumes, saved truthful answers, and delegated salary-expectation policy. Do not request routine per-job review where existing authorization satisfies the active tool's rules. Approval does not supply missing facts.
- The instruction responds to the concrete Graphcore handoff described immediately beforehand. Sharing the verified email, phone, exact approved May 2028 internship resume text, and truthful work-status/sponsorship answers with **Graphcore Early Careers through Greenhouse**, for **Firmware Engineering Intern, Austin, requisition 8842203002**, and submitting that application is approved. See `private/browser-approvals.json` for the exact destination/data record. Revalidate eligibility, duplicates, form state, and answers before submitting; no immediate run was requested here.
- The user's general request is standing application authorization, not proof of action-time confirmation or destination-specific browser consent for all future recipients. The current browser tool requires sensitive-data preapproval naming specific data and destination. Use matching saved approvals when present; do not ask again unless data, destination, purpose, or risk materially changes. Do not invent approvals for unnamed employers.
- A missing destination-specific browser approval, fact, file attachment, or individual-site handoff must checkpoint **that application** and continue other permitted applications and public discovery. It must not end the whole scheduled run solely because one role is blocked. If all currently usable destinations are blocked, save the unapproved employer/data list for one batched review and continue public discovery within the time/usage limits; do not type private data first or repeat unchanged blockers.
- CAPTCHA, new credential entry, non-email MFA, binding agreements, and new security-sensitive access remain subject to the active tool's action-time confirmation or handoff requirements. This instruction does not disable those controls. Keep the existing exclusions for outreach, payments, offer acceptance, and false answers.

## Confirmed answers and generated company responses — 2026-10-03

User requests generating company-specific ordinary answers from their information/resume. This authorizes drafted motivation and preference responses supported by approved material; it does not authorize invented achievements, legal facts, or bypassing employer-required unaided assessments. Save exact text and supporting evidence.

School start: August 2023. Internship start: May 31, 2027, superseding the prior June approximation for internships. User states eligibility for any country with sponsorship required immediately or in the future. CPT and OPT have not been requested; use N/A for applicable free-text date questions, never fabricated dates or current permit claims. User-supplied GitHub: https://github.com/khanh-nguyen-nam (terminal punctuation removed and public profile verified). New-grad availability stays June 2027 unless separately changed.

User explicitly requests fixing Formlabs duplicate reconciliation, completing Gmail backfill/review, repairing Jobright profile/disclosures, testing file-only resume delivery, and resolving Resideo verification. This authorizes read-only receipt/account-history inspection, local record corrections, verified Jobright profile edits, and a non-submitting upload test at the previously approved Graphcore destination. No new application submissions are requested by these repairs.

User confirmed on 2026-10-03: Male, heterosexual/straight, not a veteran, no disability, and not LGBTQ+. Save and reuse these answers for equivalent optional employer questions and Jobright profile verification. Pronouns remain unconfirmed.


## US priority and sign-in instructions — 2026-10-03

User instruction: “for now, focus on the US market first. For every consent, click approve for me, knowing that I have read and accept them. for sign in, sent the code and open my gmail to take it”.

US jobs are the active discovery/application market for now, superseding worldwide search priority while retaining all historical records and relocation willingness. Routine non-binding application consents may be approved within authorized scope. This instruction does not supply action-time confirmation for unidentified future binding agreements or expand security access. It responds to the current Formlabs/MyGreenhouse sign-in/agreement blocker: the user has now confirmed acceptance of the current MyGreenhouse sign-in agreement, so complete this specific sign-in and inspect history. Request the email code, read the matching newest message from namkhanh052005@gmail.com, and enter it into the same challenge without saving/displaying it. Future binding terms follow active browser rules. No new application submission is requested in this preference/sign-in repair turn.

## Unattended usage efficiency — 2026-10-04

User instruction: “decrease the usage to maximize jon application overnight. do everything without my approval because I will not online.” Optimize the existing 5 AM, at-most-five-hour scheduled application run for new confirmed submissions. Proceed with authorized routine applications, verified data and ordinary non-binding consents without asking or waiting for the user. Prioritize actionable saved candidates, short incremental duplicate checks and supported direct forms. Defer broad Gmail historical backfill and repeated public discovery; preserve exact cursors. Do not re-open unchanged blockers or spend the allowance waiting for approvals. Mandatory tool confirmations, CAPTCHA, unknown required facts and unaided assessments remain role-specific checkpoints; continue other eligible applications. If no actionable permitted work remains after bounded discovery, save and end early to conserve allowance. This update does not authorize fabricated facts, bypasses, outreach or payments, and does not start an immediate run.

## Email results saved for reuse — 2026-10-04

User requests recording everything relevant from each email check in the sheet, then pulling from those records to avoid repeated mailbox reads and usage. Save all relevant receipt/status/action/review decisions and evidence pointers; refresh the Excel tracker after each email check. Reuse message decisions and completed coverage before fetching mail again. Only new messages, incomplete/conflicting evidence or exact duplicate/submission uncertainty justify another fetch. Keep secrets and unrelated email out of the sheet.

## Jobright only and final Gmail snapshot — 2026-10-04
User now requests Jobright for all job discovery and application entry to conserve usage. Use Jobright searches/recommendations and Apply with Autofill, then verify the actual employer form, approved resume delivery and employer confirmation. Do not spend usage searching other boards, public repositories or general web job lists. Preserve US role/eligibility filters. Do not enable a separate paid Jobright Agent subscription. After the one final Gmail reconciliation into private/applications.xlsx, tracking uses the local sheet/canonical local records only: recurring Gmail sync is disabled, and application runs must not read Gmail for status, duplicate receipts, background scans or historical backfill. Use local exact requisition records and employer confirmation/history within the authorized Jobright application flow; uncertain duplicates remain blocked. New messages/manual external applications after the snapshot are not automatically imported; never claim live mailbox coverage or infer outcomes. Matching transient email sign-in codes remain authorized and must never be saved in the tracker. This update supersedes older instructions requiring Gmail reconciliation before each run.

## Employer account creation and email activation — 2026-10-04
User explicitly authorizes employer account signup during qualifying Jobright application flows with the common email namkhanh052005@gmail.com and the previously supplied common password, plus opening matching activation/verify-email links from that mailbox. User reaffirms automatic approval for these application-related actions. Use an existing signed-in session or browser/password-manager saved common credential when available; do not guess or recreate a password that is unavailable. Never store, print or push passwords, codes, activation URLs/tokens or message bodies. This extends Gmail access to narrowly matching account activation messages, not status sync.

After initiating signup, search only the matching portal/sender/recipient and signup time. Verify the message is for the account just created and the destination belongs to the same employer or its identified ATS/authentication provider. Follow only its account activation/verify-email action; a matching short redirect to the same verified provider is permitted. Never follow unrelated email actions, reset/recovery/security-change links or new unverified domains. Verify activation in the portal, return to the same application, and continue automatically. Record employer/ATS account routing and activation completion without the tokenized URL or secret. Equivalent email OTP signin remains authorized. Mandatory browser confirmations, CAPTCHA and non-email MFA still follow active tool rules; checkpoint only that role and continue. Recurring Gmail status sync remains disabled.
