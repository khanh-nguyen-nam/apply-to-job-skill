import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root='/Users/macboookpro/khanh-dev/mass-apply';
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(`${root}/private/applications.xlsx`));
const sheet=wb.worksheets.getItem('Applications');
const table=sheet.tables.items[0];
const columns=table.getHeaderRowRange().values[0].map(k=>k.replaceAll(' ','_'));
const rows=JSON.parse(await fs.readFile(`${root}/work/excel/run-outcome-source.json`,'utf8'));
const existing=table.getDataRows();
const idcol=columns.indexOf('application_id');
const indexes=new Map(existing.map((r,i)=>[r[idcol],i]));
const dates=new Set(['applied_at','posted_at','discovered_at','last_action_at','last_email_at','status_updated_at','action_due_at']);
const sync=new Set(['status','applied_at','last_email_at','gmail_thread_ids','status_updated_at','last_action_at','evidence_path','next_action','notes','confirmation_url','blocker','role','requisition_id','resume_delivery','resume_id','resume_sha256','discovered_at','jobright_url','apply_url','canonical_url','job_type','location','country','company','ats','ats_tenant','jobright_status']);
function localDate(v){if(!v)return null;const d=new Date(v);if(Number.isNaN(d.getTime()))return v;const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'America/Indiana/Indianapolis',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(d).map(p=>[p.type,p.value]));return new Date(`${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}Z`)}
function value(row,k){return dates.has(k)?localDate(row[k]):row[k]||null}
let added=0,updated=0;
for(const row of rows){const idx=indexes.get(row.application_id);if(idx===undefined){table.rows.add(null,[columns.map(k=>value(row,k))]);added++;}else if(['APP-dd25732e2858','APP-c2dfe19968b9'].includes(row.application_id)){for(let j=0;j<columns.length;j++)if(sync.has(columns[j]))sheet.getRangeByIndexes(idx+4,j,1,1).values=[[value(row,columns[j])]];updated++;}}
const data=table.getDataRows();
if(data.length!==rows.length||new Set(data.map(r=>r[idcol])).size!==data.length)throw new Error('Tracker row or unique ID mismatch');
const find=id=>data.find(r=>r[idcol]===id);
for(const [id,status] of [['APP-dd25732e2858','skipped'],['APP-c2dfe19968b9','blocked']])if(!find(id)||find(id)[columns.indexOf('status')]!==status)throw new Error(`Status verification failed ${id}`);
if(added){const start=existing.length+4;const range=sheet.getRangeByIndexes(start,0,added,columns.length);range.format.rowHeight=65;range.format.wrapText=true;range.format.verticalAlignment='top';range.format.font={name:'Arial',size:11,color:'#172337'};for(let j=0;j<columns.length;j++)if(dates.has(columns[j]))sheet.getRangeByIndexes(start,j,added,1).setNumberFormat('yyyy-mm-dd hh:mm');}
const errors=(await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A',options:{useRegex:true,maxResults:20},maxChars:1000})).ndjson;
if(!errors.includes('matched 0 entries'))throw new Error('Workbook formula-error scan not clean: '+errors);
await (await SpreadsheetFile.exportXlsx(wb)).save(`${root}/private/applications.xlsx`);await fs.chmod(`${root}/private/applications.xlsx`,0o600);
const last=existing.length+4+added;const png=await wb.render({sheetName:'Applications',range:`A${last}:G${last}`,scale:1.2,format:'png'});await fs.writeFile(`${root}/work/excel/run-outcome-preview.png`,new Uint8Array(await png.arrayBuffer()));
console.log(JSON.stringify({added,updated,rows:data.length,pentangle:find('APP-dd25732e2858')[columns.indexOf('status')],cisco:find('APP-c2dfe19968b9')[columns.indexOf('status')],formulaErrors:errors}));
