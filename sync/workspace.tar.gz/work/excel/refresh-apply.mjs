import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root='/home/nkhanh/khanh-dev/mass-apply';
const output='/home/nkhanh/Documents/Codex/2026-10-02/use-apply-to-job-to-submit/outputs/applications.xlsx';
const rows=JSON.parse(await fs.readFile(`${root}/work/apply-linux-20261004T090136Z/excel-source.json`,'utf8'));
const run=JSON.parse(await fs.readFile(`${root}/private/runs/apply-linux-20261004T090136Z.json`,'utf8'));
const changed=new Set(run.changed_application_ids);
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(`${root}/private/applications.xlsx`));
const sheet=wb.worksheets.getItem('Applications'), table=sheet.tables.items[0];
const columns=table.getHeaderRowRange().values[0].map(k=>k.replaceAll(' ','_'));
const existing=table.getDataRows(), idcol=columns.indexOf('application_id');
const indices=new Map(existing.map((r,i)=>[r[idcol],i]));
const dates=new Set(['applied_at','posted_at','discovered_at','last_action_at','last_email_at','status_updated_at','action_due_at']);
const syncFields=new Set(['status','applied_at','last_email_at','gmail_thread_ids','status_updated_at','last_action_at','evidence_path','next_action','notes','confirmation_url','blocker','role','requisition_id','resume_delivery','resume_id','resume_sha256']);
function localDate(value){if(!value)return null; const d=new Date(value);if(Number.isNaN(d.getTime()))return value;const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'America/Indiana/Indianapolis',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(d).map(p=>[p.type,p.value]));return new Date(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`);}
function value(row,k){return dates.has(k)?localDate(row[k]):row[k]||null;}
let added=0,updated=0;
for(const row of rows){const index=indices.get(row.application_id);if(index===undefined){table.rows.add(null,[columns.map(k=>value(row,k))]);added++;}else if(changed.has(row.application_id)){for(let j=0;j<columns.length;j++)if(syncFields.has(columns[j]))sheet.getRangeByIndexes(index+4,j,1,1).values=[[value(row,columns[j])]];updated++;}}
const actual=table.getDataRows().find(r=>r[idcol]==="APP-0e11afa94069"); if(actual[columns.indexOf("status")]!=="applied"||actual[columns.indexOf("resume_delivery")]!=="employer_pdf_attachment"||!actual[columns.indexOf("applied_at")]||!actual[columns.indexOf("confirmation_url")])throw Error("Graphcore verification failed"); const count=table.getDataRows().length;
if(count!==rows.length||new Set(table.getDataRows().map(r=>r[idcol])).size!==count)throw Error('Tracker row or ID mismatch');
if(added){const range=sheet.getRangeByIndexes(existing.length+4,0,added,columns.length);range.format.rowHeight=65;range.format.wrapText=true;range.format.verticalAlignment='top';range.format.font={name:'Arial',size:11,color:'#172337'};}
for(let j=0;j<columns.length;j++)if(dates.has(columns[j]))sheet.getRangeByIndexes(4,j,count,1).setNumberFormat('yyyy-mm-dd hh:mm');
for(const id of ['APP-4567fdd0b73c','APP-921719707985','APP-90d94343661e']){const actual=table.getDataRows().find(r=>r[idcol]===id),expected=rows.find(r=>r.application_id===id);if(!actual||actual[columns.indexOf('status')]!==expected.status)throw Error(`Status mismatch ${id}`);}
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A',options:{useRegex:true,maxResults:20},maxChars:800})).ndjson);
const preview=await wb.render({sheetName:'Applications',range:`A${existing.length+4}:F${existing.length+8}`,scale:1.3,format:'png'});await fs.writeFile(`${root}/work/excel/preview-sync.png`,new Uint8Array(await preview.arrayBuffer()));
await (await SpreadsheetFile.exportXlsx(wb)).save(output);
await fs.copyFile(output,`${root}/private/applications.xlsx`);await fs.chmod(`${root}/private/applications.xlsx`,0o600);
console.log(JSON.stringify({added,updated,count,output}));
