import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load('/home/nkhanh/khanh-dev/mass-apply/private/applications.xlsx'));
console.log((await wb.inspect({kind:'sheet',include:'id,name',maxChars:1000})).ndjson);
console.log((await wb.inspect({kind:'table',range:'Applications!A4:H6',include:'values',tableMaxRows:3,tableMaxCols:8,maxChars:2000})).ndjson);
const png=await wb.render({sheetName:'Applications',range:'A1:F8',scale:1.5,format:'png'});await fs.writeFile('/home/nkhanh/khanh-dev/mass-apply/work/excel/before.png',new Uint8Array(await png.arrayBuffer()));
