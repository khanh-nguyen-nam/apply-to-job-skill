import json,csv,datetime,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('private');rid='gmail-linux-20261004T080206Z';runpath=root/'runs'/f'{rid}.json';run=json.loads(runpath.read_text());rows=list(csv.DictReader((root/'applications.csv').open()));ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(root/'applications.xlsx') as z:
 ss=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
 sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'));cells={}
 for c in sheet.findall('.//m:sheetData/m:row/m:c',ns):
  v=c.find('m:v',ns);inline=c.find('m:is',ns);text=(v.text or '') if v is not None else ''.join(inline.itertext()) if inline is not None else ''
  if c.attrib.get('t')=='s':text=ss[int(text)]
  cells[c.attrib['r']]=text
 assert {v for v in cells.values() if v.startswith('APP-')}=={r['application_id'] for r in rows}
 for aid in run['changed_application_ids']:
  r=next(r for r in rows if r['application_id']==aid);cell=next(k for k,v in cells.items() if v==aid);rownum=''.join(c for c in cell if c.isdigit());assert cells.get('C'+rownum)==r['status'],aid
now=datetime.datetime.now(datetime.timezone.utc).isoformat();statepath=root/'gmail-sync-state.json';state=json.loads(statepath.read_text())
events=[json.loads(s) for s in (root/'events.jsonl').read_text().splitlines() if s];new=[e for e in events if e.get('run_id')==rid]
state['notified_event_ids']=sorted(set(state.get('notified_event_ids',[]))|{e['event_id'] for e in new if 'event_id' in e})
state['review_notified_message_ids']=sorted(set(state.get('review_notified_message_ids',[]))|{'1a10412cbf654ac1'})
state['last_run']={'run_id':rid,'started_at':run['started_at'],'completed_at':now,'connector':'Composio Gmail','account_verified':state['mailbox'],'incremental_scanned':98,'new_decisions':35,'applications_created':20,'tracker_rows':len(rows),'workbook_verified':True,'historical_backfill_complete':True}
statepath.write_text(json.dumps(state,indent=2)+'\n');statepath.chmod(384)
run.update(status='completed',completed_at=now,workbook_verified=True,connector='Composio Gmail',notification_summary='20 newly identified applications, two Amazon rejections, one Waymo rejection; Microsoft Maia research internship needs a reference letter, and a separate self-addressed reference request needs verification.')
runpath.write_text(json.dumps(run,indent=2)+'\n');runpath.chmod(384)
with (root/'events.jsonl').open('a') as f:f.write(json.dumps({'timestamp':now,'event':'gmail_sync_completed','run_id':rid,'incremental_complete':True,'backfill_complete':True,'tracker_rows':len(rows),'workbook_verified':True})+'\n')
lock=root/'runs/gmail-sync-active.lock';assert json.loads(lock.read_text())['run_id']==rid;lock.unlink()
print(json.dumps({'tracker_rows':len(rows),'incremental_complete':True,'workbook_verified':True,'lock_released':True}))
