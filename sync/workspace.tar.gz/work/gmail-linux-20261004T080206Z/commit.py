import csv,json,datetime,hashlib,os
from pathlib import Path
root=Path('private');work=Path('work/gmail-linux-20261004T080206Z');rid='gmail-linux-20261004T080206Z';now=datetime.datetime.now(datetime.timezone.utc).isoformat();runpath=root/'runs'/f'{rid}.json';run=json.loads(runpath.read_text());scan=json.loads((work/'scan.json').read_text())
assert json.loads((root/'runs/gmail-sync-active.lock').read_text())['run_id']==rid
for p in (root/'runs').glob('*.json'):
 d=json.loads(p.read_text())
 if d.get('status') in ['running','in_progress'] and d.get('run_id')!=rid:raise RuntimeError('Concurrent writer '+str(p))
original=(root/'applications.csv').read_bytes();rows=list(csv.DictReader((root/'applications.csv').open()));fields=list(rows[0]);state=json.loads((root/'gmail-sync-state.json').read_text());review=json.loads((root/'gmail-review.json').read_text());processed=set(state['processed_message_ids']);events=[];decisions=[];new=[];changed=set()
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
for m in sorted(json.loads((work/'observations.json').read_text()),key=lambda m:m['date']):
 mid=m['id']
 if mid in processed:continue
 rec={'mailbox':state['mailbox'],'message_id':mid,'thread_id':m['thread'],'received_at':m['date'],'from':m['sender'],'subject':m['subject'],'excerpt':m['body'][:650],'gmail_url':'https://mail.google.com/mail/u/0/#all/'+mid,'processed_at':now}
 spec=scan['specs'].get(mid)
 if spec:
  company,role,req,status=spec;reference=status=='reference'
  matches=[r for r in rows if r['company'].casefold()==company.casefold() and ((req and r['requisition_id']==req) or (not req and r['role']==role))]
  assert len(matches)<2,'Ambiguous identity '+mid
  if not matches:
   assert not reference
   aid='APP-'+hashlib.sha256((company.casefold()+'|'+(req or role.casefold())).encode()).hexdigest()[:12];assert not any(r['application_id']==aid for r in rows)
   r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,requisition_id=req,status=status,submission_source='external_unknown',discovered_at=now,status_updated_at=m['date']);rows.append(r);new.append(aid);prior=None
  else:r=matches[0];aid=r['application_id'];prior=r['status']
  if not reference and (not r['status_updated_at'] or dt(m['date'])>=dt(r['status_updated_at'])):
   # A delayed acknowledgement must not downgrade an advanced stage.
   if status!='applied' or r['status'] in ['applied','discovered','queued','prepared','blocked','in_progress','submission_unknown']:r['status']=status;r['status_updated_at']=m['date']
   else:rec['status_conflict']='Acknowledgment retained as evidence; current advanced outcome preserved.'
  if status=='applied' and (not r['applied_at'] or dt(m['date'])<dt(r['applied_at'])):r['applied_at']=m['date']
  r['gmail_thread_ids']=';'.join(sorted(set(filter(None,r['gmail_thread_ids'].split(';')))|{m['thread']}));r['last_email_at']=max(filter(None,[r['last_email_at'],m['date']]),key=dt);r['last_action_at']=now
  if reference:r['next_action']='Request supporting reference letter through Microsoft Careers > Action Center > Forms Manager > References; select an appropriate referee.';r['notes']=(r['notes']+'; ' if r['notes'] else '')+'Reference letter required. No deadline stated; no request sent by this sync.'
  elif r['status']=='rejected':r['next_action']='';r['action_due_at']=''
  rec.update(application_id=aid,company=company,role=role,requisition_id=req,decision='matched',status=r['status'],match_strength='employer_and_requisition' if req else 'unique_employer_exact_role_cycle')
  folder=root/'applications'/aid;folder.mkdir(exist_ok=True);p=folder/f'email-{mid}.json';p.write_text(json.dumps(rec,indent=2)+'\n');p.chmod(384)
  if not r['evidence_path'] or prior!=r['status']:r['evidence_path']=str(p)
  if not r['confirmation_url'] and status=='applied':r['confirmation_url']=rec['gmail_url']
  changed.add(aid);e={'timestamp':now,'application_id':aid,'event':'reference_letter_required' if reference else 'gmail_application_reconciled','prior_status':prior,'new_status':r['status'],'message_id':mid,'event_at':m['date'],'evidence_path':str(p),'run_id':rid};e['event_id']=hashlib.sha256((state['mailbox']+'|'+mid+'|'+aid+'|'+e['event']).encode()).hexdigest();events.append(e)
 elif mid in ['1a104103d718845d','1a1032393d762d8b']:rec.update(decision='informational',excerpt='Conditional application-progress notice or job alert; not a submission or stage change.')
 else:
  selfref=mid=='1a10412cbf654ac1'
  rec.update(decision='needs_review',review_reason='Reference request was addressed to the applicant mailbox, listing Khanh Nguyen as the referee; role is unspecified. Verify the intended referee in Microsoft Careers.' if selfref else 'Generic employer receipt has no role/requisition; preserve unassigned evidence.',user_action_required=selfref)
  if not any(x.get('message_id')==mid for x in review['items']):review['items'].append(rec)
 decisions.append(rec);processed.add(mid)
assert (root/'applications.csv').read_bytes()==original
p=root/'applications.csv';tmp=p.with_suffix('.tmp')
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
assert len(list(csv.DictReader(tmp.open())))==len(rows);tmp.chmod(384);os.replace(tmp,p)
for name,items in [('events.jsonl',events),('gmail-messages.jsonl',decisions)]:
 with (root/name).open('a') as f:
  for item in items:f.write(json.dumps(item)+'\n')
state['processed_message_ids']=sorted(processed);state['last_incremental_completed_at']=run['started_at'];state['incremental_pending']=None;state['last_incremental_query']=scan['query'];state['last_incremental_scan_count']=len(scan['page']['messages']);state['last_incremental_run_at']=run['started_at']
for p,d in [(root/'gmail-sync-state.json',state),(root/'gmail-review.json',review)]:p.write_text(json.dumps(d,indent=2)+'\n');p.chmod(384)
run.update(incremental_complete=True,incremental_scan_count=len(scan['page']['messages']),new_decisions=len(decisions),new_application_ids=new,changed_application_ids=sorted(changed),tracker_rows=len(rows),backfill_complete=state['backfill']['status']=='complete')
runpath.write_text(json.dumps(run,indent=2)+'\n');runpath.chmod(384)
(work/'excel-source.json').write_text(json.dumps(rows));(work/'excel-source.json').chmod(384)
print(json.dumps({'new_records':len(new),'changed':len(changed),'decisions':len(decisions),'tracker_rows':len(rows)}))
