import csv,json,hashlib,datetime,os,re
from pathlib import Path
root=Path('private'); work=Path('work/gmail-linux-20261003T080204Z'); rid='gmail-linux-20261003T080204Z'
runpath=root/'runs'/f'{rid}.json';run=json.loads(runpath.read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert json.loads((root/'runs/gmail-sync-active.lock').read_text())['run_id']==rid
for p in (root/'runs').glob('*.json'):
 d=json.loads(p.read_text())
 if d.get('status') in ['running','in_progress'] and d.get('run_id')!=rid:raise RuntimeError('Competing writer: '+str(p))
original=(root/'applications.csv').read_bytes(); rows=list(csv.DictReader((root/'applications.csv').open()));fields=list(rows[0]);state=json.loads((root/'gmail-sync-state.json').read_text());review=json.loads((root/'gmail-review.json').read_text());processed=set(state['processed_message_ids']);events=[];decisions=[];changed=set();new=[]
recent=json.loads((work/'recent-observations.json').read_text());history=json.loads((work/'history-page.json').read_text())
def dated(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def identity(m):
 b=m['body'];sender=m['sender'];mid=m['id']
 if 'noreply@tesla.com' in sender:
  x=re.search(r'application for the (.+?),\s*(\d+) position',b);return ('Tesla',x[1].strip(),x[2],'applied') if x else None
 if mid=='1a0fe60168171c21':return ('Samsung','Senior Staff Engineer, Debug & Validation Engineer','','applied')
 if mid=='1a0fe4adbfdc7170':return ('Amazon','Software Development Engineer Intern (Embedded Systems) - Summer 2027 (USA)','10567914','applied')
 if 'recruiting.facebook.com' in sender:
  x=re.search(r'application for the (.+?) role\.',b);return ('Meta',x[1],'','applied') if x else None
 if mid=='1a0fe3837b7de55f':return ('NVIDIA','Applied Systems Engineering Rotation Engineer - New College Graduate 2026','JR2024713','applied')
 if 'shure+' in sender:
  x=re.search(r'application to the (.+?) position at Shure',b);return ('Shure',x[1],'','applied') if x else None
 specs={
 '1a0a8677bef2faf9':('SK hynix memory solutions America Inc.','Embedded Software Engineer Intern','','applied'),
 '1a0a5d761d998295':('Mind Robotics','Firmware Engineer','','rejected'),
 '1a0a2ff491c5caad':('Micron','Engineer, Test Solutions','','applied'),
 '1a0a2fa818ba29f0':('Cadence','Firmware Engineer II','','applied'),
 '1a0a1c193bfd0b03':('EquipmentShare','Intern: Engineering (Embedded)','','applied'),
 '1a0a1a2128694625':('The Toro Company','Embedded Software Engineering Intern - The Toro Company','JR17125','applied'),
 '1a0a0f011cf886e8':('AMD','Interconnect Firmware Engineer','2026-86125','rejected')}
 return specs.get(mid)
for historical,m in [(False,m) for m in recent]+[(True,m) for m in history['observations']]:
 mid=m['id']
 if mid in processed:continue
 evidence={'mailbox':state['mailbox'],'message_id':mid,'thread_id':m['thread'],'received_at':m['date'],'from':m['sender'],'subject':m['subject'],'gmail_url':'https://mail.google.com/mail/u/0/#all/'+mid,'excerpt':m['body'][:650],'processed_at':now,'historical':historical}
 spec=identity(m);reference=mid=='1a0fe383f217cd56'
 if reference:spec=('Microsoft','Research Intern - Security Research Group, Microsoft Research Redmond','200059346',None)
 if spec:
  company,role,req,status=spec
  matches=[r for r in rows if r['company'].casefold()==company.casefold() and ((req and r['requisition_id']==req) or (not req and r['role']==role))]
  if len(matches)>1:raise RuntimeError('Ambiguous match '+mid)
  if not matches:
   assert not reference
   aid='APP-'+hashlib.sha256((company.casefold()+'|'+(req or role.casefold())).encode()).hexdigest()[:12];assert not any(r['application_id']==aid for r in rows)
   r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,requisition_id=req,status=status,submission_source='external_unknown',discovered_at=now,job_type='internship' if 'intern' in role.lower() else '',status_updated_at=m['date']);rows.append(r);new.append(aid);prior=None
  else:r=matches[0];aid=r['application_id'];prior=r['status']
  if status and (not r['status_updated_at'] or dated(m['date'])>=dated(r['status_updated_at'])):r['status']=status;r['status_updated_at']=m['date']
  if status=='applied' and (not r['applied_at'] or dated(m['date'])<dated(r['applied_at'])):r['applied_at']=m['date']
  r['gmail_thread_ids']=';'.join(sorted(set(filter(None,r['gmail_thread_ids'].split(';')))|{m['thread']}));r['last_email_at']=max(filter(None,[r['last_email_at'],m['date']]),key=dated);r['last_action_at']=now
  if reference:
   r['next_action']='Request required reference letter in Microsoft Careers > Action Center > Forms Manager > References; user must choose a referee.'
   r['notes']=(r['notes']+'; ' if r['notes'] else '')+'Employer requires a supporting reference letter; no deadline stated. No referee request sent.'
  elif prior is None:r['next_action']='Monitor employer response' if status=='applied' else ''
  evidence.update(application_id=aid,company=company,role=role,requisition_id=req,decision='matched',status=r['status'],match_strength='employer_and_requisition' if req else 'unique_employer_exact_role',event_type='reference_letter_required' if reference else 'application_status')
  folder=root/'applications'/aid;folder.mkdir(exist_ok=True);path=folder/f'email-{mid}.json';path.write_text(json.dumps(evidence,indent=2)+'\n');path.chmod(384)
  if not r['evidence_path'] or prior!=r['status']:r['evidence_path']=str(path)
  if not r['confirmation_url'] and status=='applied':r['confirmation_url']=evidence['gmail_url']
  changed.add(aid);event={'timestamp':now,'application_id':aid,'event':'reference_letter_required' if reference else 'gmail_application_reconciled','prior_status':prior,'new_status':r['status'],'message_id':mid,'event_at':m['date'],'evidence_path':str(path),'historical':historical,'run_id':rid};event['event_id']=hashlib.sha256((state['mailbox']+'|'+mid+'|'+aid+'|'+event['event']).encode()).hexdigest();events.append(event)
 elif mid=='1a0fe478c621dd21':evidence.update(decision='informational',excerpt='Conditional application progress notice; explicit receipt is separately reconciled for requisition 10567914.')
 else:
  evidence.update(decision='needs_review',review_reason='Employer receipt lacks role/requisition identity; do not infer identity from nearby applications.',user_action_required=False)
  if not any(x.get('message_id')==mid for x in review['items']):review['items'].append(evidence)
 decisions.append(evidence);processed.add(mid)
assert (root/'applications.csv').read_bytes()==original,'Concurrent CSV change'
p=root/'applications.csv';tmp=p.with_suffix('.tmp')
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
assert len(list(csv.DictReader(tmp.open())))==len(rows);tmp.chmod(384);os.replace(tmp,p)
for name,items in [('events.jsonl',events),('gmail-messages.jsonl',decisions)]:
 with (root/name).open('a') as f:
  for item in items:f.write(json.dumps(item)+'\n')
state['processed_message_ids']=sorted(processed);state['last_incremental_completed_at']=run['started_at'];state['incremental_pending']=None;state['last_incremental_scan_count']=67
state['backfill'].update(pending_page_token='16598642139531600363',pending_message_ids=history['pending_message_ids'],pending_next_page_token=history['next_page_token'],messages_processed=state['backfill']['messages_processed']+len(history['observations']),oldest_processed_at=min(m['date'] for m in history['observations']),note='Historical page partially processed; resume pending IDs before fetching its next page. Coverage incomplete.')
for path,data in [(root/'gmail-sync-state.json',state),(root/'gmail-review.json',review)]:path.write_text(json.dumps(data,indent=2)+'\n');path.chmod(384)
run.update(incremental_complete=True,incremental_scan_count=67,incremental_new_decisions=len(recent),backfill_new_decisions=len(history['observations']),new_application_ids=new,changed_application_ids=sorted(changed),tracker_rows=len(rows),backfill_complete=False,backfill_pending_count=len(history['pending_message_ids']))
runpath.write_text(json.dumps(run,indent=2)+'\n');runpath.chmod(384)
(work/'excel-source.json').write_text(json.dumps(rows));(work/'excel-source.json').chmod(384)
print(json.dumps({'new_records':len(new),'changed_records':len(changed),'decisions':len(decisions),'tracker_rows':len(rows),'reference_letter_action_required':True}))
