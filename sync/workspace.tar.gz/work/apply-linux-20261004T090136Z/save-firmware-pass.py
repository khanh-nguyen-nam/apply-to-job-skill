import csv, datetime, hashlib, json, os, pathlib
root=pathlib.Path('/home/nkhanh/khanh-dev/mass-apply'); p=root/'private'; rid='apply-linux-20261004T090136Z'; work=root/'work'/rid
assert json.loads((p/'runs/apply-active.lock').read_text())['run_id']==rid
rows=list(csv.DictReader((p/'applications.csv').open())); fields=list(rows[0]); now=datetime.datetime.now(datetime.timezone.utc).isoformat(); changed=[]
def add(company,role,req,url,status,blocker,next_action,kind,artifact=None):
    old=next((r for r in rows if r['company']==company and r['requisition_id']==req),None)
    if old:return old
    aid='APP-'+hashlib.sha256((company+'|'+req+'|'+role).encode()).hexdigest()[:12]
    r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,requisition_id=req,canonical_url=url,apply_url=url,status=status,blocker=blocker,next_action=next_action,job_type=kind,country='United States',discovered_at=now,last_action_at=now)
    d=p/'applications'/aid;d.mkdir(exist_ok=True,mode=0o700)
    if artifact:
        dest=d/'public-form.txt';dest.write_text((work/artifact).read_text());os.chmod(dest,0o600);r['evidence_path']=str(dest.relative_to(root))
    rows.append(r);changed.append(aid);return r
s=add('Solidigm','2027 Graduate Software, Firmware & AI Engineering Internships - US','744000147613769','https://jobs.smartrecruiters.com/Solidigm/744000147613769-2027-graduate-software-firmware-ai-engineering-internships-us','blocked','browser_destination_data_consent_required','Obtain named consent for verified contact, city, education, approved May 2028 PDF and sponsorship; inspect subsequent pages before submission','internship','solidigm-public-form.txt')
s['location']='Rancho Cordova / San Jose, California';s['notes']='Live employer posting and native Easy Apply form verified. Graduate CE accepted; firmware/storage/Linux tasks match resume. Prior Solidigm receipt specifically Poland, not this U.S. requisition. First page supports native PDF resume; no private data entered.'
a=add('Apptronik','Firmware Engineer – Hands','6216205004','https://job-boards.greenhouse.io/embed/job_app?for=apptronik&token=6216205004','blocked','missing_required_citizenship_export_history_facts_and_destination_consent','Confirm citizenship/protected-person status and export-control criminal/ineligibility facts; obtain named data consent; verify June 2027 start acceptance','new_grad','apptronik-public-form.txt')
a['location']='Austin, Texas';a['notes']='0–2 years role accepts internship/research experience. Public employer form asks citizenship/permanent residency, export-control convictions and government ineligibility. These are not answered by F-1 or work-authorization facts. No private data entered.'
c=add('Acuity','Specialist Firmware Engineering BUILD Program (July)','16326','https://careers.acuityinc.com/job/Atlanta-Specialist-Firmware-Engineering-BUILD-Leadership-Program-GA-30309/1428876800/','skipped','required_degree_mismatch','Revisit only if employer confirms Computer Engineering qualifies','new_grad','acuity-public-posting.txt')
c['location']='Atlanta, Georgia';c['notes']='Native posting specifies required BS/BA Electrical Engineering or Electrical; approved profile is Computer Engineering. Starts July 12, 2027. Do not alter degree to meet screening. WhiteOptics duplicate aggregator title should resolve to the same employer requisition before any application.'
for role,req,mid,stamp in [('2027 Summer Intern: Engineering - Firmware','105414','1a03652b1e031ca5','2026-08-25T00:29:43Z'),('2027 Summer Intern: Engineering - Embedded Systems','104987','1a03651aff8221ad','2026-08-25T00:28:37Z')]:
    h=add('Hubbell',role,req,'','applied','','Await employer response; do not resubmit this requisition','internship')
    h.update(applied_at=stamp,status_updated_at=stamp,last_email_at=stamp,submission_source='external_unknown',gmail_thread_ids='1a03651aff8221ad',confirmation_url='https://mail.google.com/mail/u/?authuser=namkhanh052005%40gmail.com#all/'+mid,notes='Exact employer receipt names requisition and role. Historical application discovered during duplicate reconciliation; not a new bot submission. Original resume unknown.')
    dest=p/'applications'/h['application_id']/'gmail-evidence.json';dest.write_text(json.dumps({'mailbox':'namkhanh052005@gmail.com','message_id':mid,'thread_id':'1a03651aff8221ad','received_at':stamp,'sender':'Hubbell Careers <careers@hubbell.com>','evidence':'Your application for the following position is in process: '+req+', '+role,'original_resume_unknown':True},indent=2));os.chmod(dest,0o600);h['evidence_path']=str(dest.relative_to(root))
    decisions=p/'gmail-messages.jsonl'
    if mid not in decisions.read_text():
        with decisions.open('a') as f:f.write(json.dumps({'mailbox':'namkhanh052005@gmail.com','message_id':mid,'processed_at':now,'decision':'applied','application_id':h['application_id'],'run_id':rid,'reason':'Exact employer/role/requisition receipt; no resubmission'})+'\n')
tmp=p/'applications.csv.tmp'
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
os.chmod(tmp,0o600);assert len(list(csv.DictReader(tmp.open())))==len(rows);tmp.replace(p/'applications.csv')
with (p/'events.jsonl').open('a') as f:
    for aid in changed:
        row=next(r for r in rows if r['application_id']==aid);f.write(json.dumps({'timestamp':now,'application_id':aid,'event':'discovery_or_history_reconciled','new_status':row['status'],'run_id':rid,'reason':row['notes']})+'\n')
queuefile=p/'runs'/f'{rid}-approval-queue.json';queue=json.loads(queuefile.read_text());print(type(queue).__name__)
runfile=p/'runs'/f'{rid}.json';run=json.loads(runfile.read_text());run['changed_application_ids']=sorted(set(run['changed_application_ids']+changed));run['counters']['blocked']+=sum(next(r for r in rows if r['application_id']==aid)['status']=='blocked' for aid in changed);run['counters']['skipped']+=sum(next(r for r in rows if r['application_id']==aid)['status']=='skipped' for aid in changed);run['historical_applications_identified']+=sum(next(r for r in rows if r['application_id']==aid)['status']=='applied' for aid in changed);run['source_cursors']['jobright_firmware']={'completed':['Solidigm graduate US','Apptronik Hands','Hubbell Firmware (duplicate 105414)','Hubbell Embedded (duplicate 104987)','Karman/Utilidata (duplicate)','Acuity BUILD'], 'next':['Cedar Electronics','Nokia embedded coop','embedded/kernel/Linux searches'],'coverage_complete':False};run['last_progress_at']=now;runfile.write_text(json.dumps(run,indent=2));(work/'excel-source.json').write_text(json.dumps(rows));print(json.dumps({'rows':len(rows),'changed':changed,'confirmed_new':run['counters']['confirmed_new']}))
