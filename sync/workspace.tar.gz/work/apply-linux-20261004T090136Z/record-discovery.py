import csv, datetime, hashlib, html, json, os, pathlib, re, urllib.request

root = pathlib.Path('/home/nkhanh/khanh-dev/mass-apply')
p = root / 'private'
rid = 'apply-linux-20261004T090136Z'
assert json.loads((p / 'runs/apply-active.lock').read_text())['run_id'] == rid
rows = list(csv.DictReader((p / 'applications.csv').open()))
fields = list(rows[0])
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
changed = []
approval_queue = []
source = json.loads((root / 'work' / rid / 'asteraearlycareer2027.json').read_text())
ids = [4731591005, 4731584005, 4731585005, 4724489005, 4724492005]
for job in source['jobs']:
    if job['id'] not in ids:
        continue
    req = str(job['id'])
    if any(r['ats_tenant'] == 'asteraearlycareer2027' and r['requisition_id'] == req for r in rows):
        continue
    aid = 'APP-' + hashlib.sha256(('Astera Labs|asteraearlycareer2027|' + req).encode()).hexdigest()[:12]
    artifact = p / 'applications' / aid
    artifact.mkdir(mode=0o700, exist_ok=True)
    posting = re.sub('<[^>]+>', ' ', html.unescape(html.unescape(job['content'])))
    (artifact / 'posting.txt').write_text(posting)
    questions = json.load(urllib.request.urlopen('https://boards-api.greenhouse.io/v1/boards/asteraearlycareer2027/jobs/' + req + '?questions=true', timeout=30))
    (artifact / 'public-form.json').write_text(json.dumps(questions, indent=2))
    data = ['Verified email', 'Verified phone', 'Approved May 2028 internship PDF', 'Purdue education (August 2023 to May 2028)', 'Truthful future sponsorship Yes']
    queue = {'application_id': aid, 'employer': 'Astera Labs', 'role': job['title'], 'requisition_id': req, 'url': job['absolute_url'], 'data': data, 'purpose': 'Fill verified internship form and submit once after duplicate and form checks'}
    approval_queue.append(queue)
    row = {k: '' for k in fields}
    row.update(application_id=aid, company='Astera Labs', role=job['title'], job_type='internship', location=job['location']['name'], country='United States', ats='Greenhouse', ats_tenant='asteraearlycareer2027', requisition_id=req, apply_url=job['absolute_url'], canonical_url=job['absolute_url'], discovered_at=now, status='blocked', last_action_at=now, resume_id='intern-2028', resume_sha256='9eb250f784f045ddd95e55191d395bad8e6229cbdca036ee61490abb3b33b412', blocker='browser_destination_data_consent_required', next_action='Use matching destination/data consent; recheck duplicates, complete verified form, attach PDF and submit once', evidence_path=str(artifact.relative_to(root) / 'public-form.json'), notes='Public employer posting and application fields inspected; local data prepared only. No private data entered. Generic Astera receipts match previously confirmed Retimer/Optical submissions; this requisition is distinct.')
    rows.append(row)
    changed.append(aid)
    (artifact / 'resume-checkpoint.json').write_text(json.dumps({**queue, 'captured_at': now, 'submission_attempted': False, 'blocker': row['blocker'], 'resume_sha256': row['resume_sha256']}, indent=2))
    for f in artifact.iterdir():
        os.chmod(f, 0o600)

tmp = p / 'applications.csv.tmp'
with tmp.open('w') as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
os.chmod(tmp, 0o600)
assert len(list(csv.DictReader(tmp.open()))) == len(rows)
tmp.replace(p / 'applications.csv')
with (p / 'events.jsonl').open('a') as f:
    for aid in changed:
        f.write(json.dumps({'timestamp': now, 'application_id': aid, 'event': 'discovery_checkpoint', 'new_status': 'blocked', 'run_id': rid, 'reason': 'Specific browser destination/data consent required; public form prepared'}) + '\n')
queue_file = p / 'runs' / (rid + '-approval-queue.json')
queue_file.write_text(json.dumps(approval_queue, indent=2))
os.chmod(queue_file, 0o600)
run_file = p / 'runs' / (rid + '.json')
run = json.loads(run_file.read_text())
run['changed_application_ids'] = sorted(set(run.get('changed_application_ids', []) + changed))
run['counters']['blocked'] += len(changed)
run['source_cursors']['greenhouse_public_boards'] = {'completed': ['asteraearlycareer2027', 'formlabsinternships', 'graphcore-early-careers'], 'new_candidates': changed, 'full_US_coverage': False}
run['approval_queue'] = str(queue_file.relative_to(root))
run['last_progress_at'] = now
run_file.write_text(json.dumps(run, indent=2))
(root / 'work' / rid / 'excel-source.json').write_text(json.dumps(rows))
print(json.dumps({'new_distinct_blocked': len(changed), 'total_rows': len(rows)}))
