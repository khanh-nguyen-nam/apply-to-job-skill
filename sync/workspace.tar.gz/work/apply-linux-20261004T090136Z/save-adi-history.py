import csv, datetime, hashlib, json, os, pathlib
root=pathlib.Path('/home/nkhanh/khanh-dev/mass-apply'); p=root/'private'; rid='apply-linux-20261004T090136Z'
assert json.loads((p/'runs/apply-active.lock').read_text())['run_id']==rid
rows=list(csv.DictReader((p/'applications.csv').open())); fields=list(rows[0]); now=datetime.datetime.now(datetime.timezone.utc).isoformat()
mail=json.loads((root/'work'/rid/'native-pass-mail.json').read_text())[2]['messages']
spec=[('1a0d7217ed80e00f','Associate Embedded Software Engineer','new_grad','APP-c60847e3bed1'),('1a0a87dcbc7e33fe','Embedded Software Engineer Intern','internship','APP-abfdaef8f8d1')]
events=[]; new=[]
for mid,role,job_type,candidate_id in spec:
    m=next(m for m in mail if m['message_id']==mid)
    assert m['sender']=='Workday Analog Devices <analogdevices@myworkday.com>'
    assert m['subject'].endswith(' - '+role)
    history=next((r for r in rows if r['company']=='Analog Devices' and r['role']==role and r['applied_at']),None)
    if history is None:
        aid='APP-'+hashlib.sha256(('Analog Devices|unresolved-requisition|'+role).encode()).hexdigest()[:12]
        artifact=p/'applications'/aid; artifact.mkdir(exist_ok=True,mode=0o700)
        evidence={'mailbox':'namkhanh052005@gmail.com',**m,'employer':'Analog Devices','role':role,'requisition_id':None,'receipt_quote':'We have received your application for the position of '+role+' and are currently reviewing your experience and qualifications.','identity_limit':'Receipt contains no requisition ID. Do not assign a current posting ID without employer history.'}
        (artifact/'gmail-evidence.json').write_text(json.dumps(evidence,indent=2)); os.chmod(artifact/'gmail-evidence.json',0o600)
        history=dict.fromkeys(fields,''); history.update(application_id=aid,company='Analog Devices',role=role,job_type=job_type,ats='Workday',ats_tenant='analogdevices',discovered_at=now,last_action_at=now,status='applied',applied_at=m['received_at'],status_updated_at=m['received_at'],last_email_at=m['received_at'],gmail_thread_ids=m['thread_id'],submission_source='external_unknown',confirmation_url='https://mail.google.com/mail/u/?authuser=namkhanh052005%40gmail.com#all/'+m['thread_id'],evidence_path=str((artifact/'gmail-evidence.json').relative_to(root)),notes='Historical exact-role employer receipt. Original requisition, location, application source and resume hash remain unknown. Current same-title posting is a possible duplicate.',next_action='Resolve employer requisition through account history before another same-title application')
        rows.append(history); new.append(aid)
        events.append({'timestamp':now,'run_id':rid,'application_id':aid,'event':'historical_receipt_imported','prior_status':None,'new_status':'applied','reason':'Explicit employer/role receipt; requisition not inferred','evidence_path':history['evidence_path']})
        with (p/'gmail-messages.jsonl').open('a') as f:f.write(json.dumps({'mailbox':evidence['mailbox'],'message_id':mid,'processed_at':now,'application_id':aid,'decision':'applied_exact_role_requisition_unresolved','run_id':rid,'evidence_path':history['evidence_path']})+'\n')
    candidate=next(r for r in rows if r['application_id']==candidate_id)
    candidate.update(blocker='possible_duplicate_prior_exact_role_receipt_and_destination_consent',next_action='Resolve original requisition in Analog Devices account history before any new submission; retain consent and eligibility blockers',last_action_at=now)
    if history['application_id'] not in candidate['notes']: candidate['notes']+=' Prior exact-role receipt: '+history['application_id']+'; original requisition unresolved, so current posting cannot be assumed new.'
    events.append({'timestamp':now,'run_id':rid,'application_id':candidate_id,'event':'duplicate_warning_verified','prior_status':'blocked','new_status':'blocked','reason':'Prior exact-title employer receipt lacks requisition; do not blindly resubmit','evidence_path':history['evidence_path']})
    cp=p/'applications'/candidate_id/'resume-checkpoint.json'; checkpoint=json.loads(cp.read_text());checkpoint.update(blocker=candidate['blocker'],next_action=candidate['next_action'],prior_application_id=history['application_id']);cp.write_text(json.dumps(checkpoint,indent=2))
tmp=p/'applications.csv.tmp'
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
os.chmod(tmp,0o600); assert list(csv.DictReader(tmp.open()))==rows; tmp.replace(p/'applications.csv')
with (p/'events.jsonl').open('a') as f:
    for e in events:f.write(json.dumps(e)+'\n')
queuepath=p/'runs'/f'{rid}-approval-queue.json';queue=json.loads(queuepath.read_text())
for e in queue:
    if e.get('application_id') in [s[3] for s in spec]:
        r=next(r for r in rows if r['application_id']==e['application_id']); e['additional_checks']=[r['notes'],r['next_action']]
queuepath.write_text(json.dumps(queue,indent=2))
runpath=p/'runs'/f'{rid}.json';run=json.loads(runpath.read_text());run['historical_applications_identified']+=len(new);run['changed_application_ids']=sorted(set(run['changed_application_ids']+new));run['last_progress_at']=now;runpath.write_text(json.dumps(run,indent=2));(root/'work'/rid/'excel-source.json').write_text(json.dumps(rows))
print(json.dumps({'historical_imports':new,'current_rows_blocked_for_duplicate_review':[s[3] for s in spec],'rows':len(rows),'confirmed_new_unchanged':run['counters']['confirmed_new']}))
