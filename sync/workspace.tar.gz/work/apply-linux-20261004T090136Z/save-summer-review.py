import csv, datetime, hashlib, json, os
from pathlib import Path
root=Path('/home/nkhanh/khanh-dev/mass-apply'); p=root/'private'; rid='apply-linux-20261004T090136Z'; work=root/'work'/rid
assert json.loads((p/'runs/apply-active.lock').read_text())['run_id']==rid
assert not [x for x in (p/'runs').glob('*active.lock') if x.name!='apply-active.lock']
now=datetime.datetime.now(datetime.timezone.utc).isoformat(); mailbox='namkhanh052005@gmail.com'
decisions=json.loads((work/'summer-decisions.json').read_text()); assert len(decisions)==54
rows=list(csv.DictReader((p/'applications.csv').open())); fields=list(rows[0]); ledger=p/'gmail-messages.jsonl'
known={(x.get('mailbox'),x.get('message_id')) for x in [json.loads(s) for s in ledger.read_text().splitlines()]}
reviewpath=p/'gmail-review.json'; review=json.loads(reviewpath.read_text()); reviewkeys={(x.get('mailbox'),x.get('message_id')) for x in review['items']}
new=[]; changed=[]; events=[]; added_decisions=0
tp=next(x for x in decisions if x['message_id']=='19fcaf7a35f01cf3')
history=next((r for r in rows if tp['message_id'] in r['gmail_thread_ids'].split(';')),None)
if not history:
    aid='APP-'+hashlib.sha256(('TP-Link Systems Inc.|unresolved-requisition|'+tp['role']).encode()).hexdigest()[:12]
    artifact=p/'applications'/aid; artifact.mkdir(mode=0o700,exist_ok=True)
    evidence={**tp,'mailbox':mailbox,'candidate_name':'Khanh Nguyen','recipient_email':mailbox,'submission_confirmed':True,'requisition_id':None,'identity_limit':'Full receipt verified; original posting ID, original resume and location unknown.'}
    (artifact/'gmail-evidence.json').write_text(json.dumps(evidence,indent=2)); os.chmod(artifact/'gmail-evidence.json',0o600)
    history=dict.fromkeys(fields,''); history.update(application_id=aid,company=tp['employer'],role=tp['role'],job_type='new_grad',ats='Workable',ats_tenant='tp-link-systems-inc',status='applied',applied_at=tp['received_at'],last_email_at=tp['received_at'],status_updated_at=tp['received_at'],last_action_at=now,discovered_at=now,gmail_thread_ids=tp['thread_id'],submission_source='external_unknown',confirmation_url='https://mail.google.com/mail/u/?authuser=namkhanh052005%40gmail.com#all/'+tp['thread_id'],evidence_path=str((artifact/'gmail-evidence.json').relative_to(root)),notes='Historical employer-confirmed application; requisition, location, resume hash and delivery remain unknown.',next_action='Verify original requisition in employer history before another same-title application')
    rows.append(history); new.append(aid); changed.append(aid)
    events.append({'timestamp':now,'run_id':rid,'application_id':aid,'prior_status':None,'new_status':'applied','event':'historical_receipt_imported','reason':'Full employer receipt confirms named applicant and role; no requisition inferred','evidence_path':history['evidence_path']})
for d in decisions:
    mid=d['message_id']; key=(mailbox,mid); matches=[r for r in rows if d['thread_id'] in r['gmail_thread_ids'].split(';')]
    mismatch=d.get('candidate_name')=='Kyle' or mid=='1a0fad0fbd96f24e'
    reason='HPE candidate identity is Kyle, not verified Khanh; do not infer ownership or map generic roles' if mismatch else 'Generic employer message lacks requisition/role; do not guess'
    ambiguous=mismatch or d['event']=='generic_receipt'
    if ambiguous and key not in reviewkeys:
        review['items'].append({'mailbox':mailbox,'message_id':mid,'thread_id':d['thread_id'],'received_at':d['received_at'],'from':d['sender'],'subject':d['subject'],'excerpt':d['short_quote'],'decision':'needs_review','review_reason':reason,'processed_at':now}); reviewkeys.add(key)
    if key not in known:
        record={'mailbox':mailbox,'message_id':mid,'thread_id':d['thread_id'],'received_at':d['received_at'],'processed_at':now,'run_id':rid,'company':d.get('employer'),'role':d.get('role'),'requisition_id':d.get('requisition_id'),'excerpt':d['short_quote'],'decision':'needs_review' if ambiguous else ('matched_existing_no_downgrade' if matches else 'no_application_stage_change')}
        if matches and not mismatch: record['application_id']=matches[0]['application_id']
        if ambiguous: record['review_reason']=reason
        with ledger.open('a') as f:f.write(json.dumps(record)+'\n')
        known.add(key); added_decisions+=1
    if d['requisition_id']=='REQ-22165':
        r=next(r for r in rows if r['application_id']=='APP-a785ddfdf8e7'); tids=set(filter(None,r['gmail_thread_ids'].split(';'))); tids.add(d['thread_id']); r['gmail_thread_ids']=';'.join(sorted(tids)); r['last_email_at']=max(r['last_email_at'],d['received_at']); changed.append(r['application_id'])
        adir=p/'applications'/r['application_id']; adir.mkdir(mode=0o700,exist_ok=True); ep=adir/('email-'+mid+'.json'); ep.write_text(json.dumps({'mailbox':mailbox,**d},indent=2)); os.chmod(ep,0o600)
        events.append({'timestamp':now,'run_id':rid,'application_id':r['application_id'],'event':'existing_receipt_reconciled','prior_status':r['status'],'new_status':r['status'],'reason':'Same employer requisition; preserved newer status and original resume evidence','evidence_path':str(ep.relative_to(root))})
q=next(r for r in rows if r['application_id']=='APP-12202a430ade'); assert q['requisition_id']=='3092573'
adir=p/'applications'/q['application_id']; adir.mkdir(mode=0o700,exist_ok=True); ep=adir/'jobright-source-identity.json'
ep.write_text(json.dumps({'observed_at':now,'employer':'Qualcomm','requisition_id':'3092573','jobright_url':'https://jobright.ai/jobs/info/6a4356a8b0f2553559ed0040','employer_url':'https://qualcomm.eightfold.ai/careers?pid=446718891829','native_posting_explicit_no_sponsorship':True,'action':'Already applied; no resubmission; historical row preserved'},indent=2)); os.chmod(ep,0o600)
tmp=p/'applications.csv.tmp'
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
os.chmod(tmp,0o600); assert list(csv.DictReader(tmp.open()))==rows; tmp.replace(p/'applications.csv')
reviewpath.write_text(json.dumps(review,indent=2)); os.chmod(reviewpath,0o600)
with (p/'events.jsonl').open('a') as f:
    for e in events:f.write(json.dumps(e)+'\n')
runpath=p/'runs'/f'{rid}.json'; run=json.loads(runpath.read_text()); run['historical_applications_identified']+=len(new); run['changed_application_ids']=sorted(set(run['changed_application_ids']+changed)); run['last_progress_at']=now
run['source_cursors']['saved_summer_receipts'].update(semantic_review_next_index=54,semantic_review_complete=True,local_decisions_path=str((work/'summer-decisions.json').relative_to(root)),global_sync_checkpoint_advanced=False)
run['source_cursors']['jobright_driver']['checked'].append('Qualcomm 3092573 verified existing application')
runpath.write_text(json.dumps(run,indent=2)); (work/'excel-source.json').write_text(json.dumps(rows)); os.chmod(work/'summer-decisions.json',0o600)
print(json.dumps({'historical_imports':new,'reviewed_messages':54,'new_decisions':added_decisions,'rows':len(rows),'confirmed_new':run['counters']['confirmed_new']}))
