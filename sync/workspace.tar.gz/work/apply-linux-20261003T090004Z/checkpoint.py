from pathlib import Path
import csv,json,datetime,hashlib,os
root=Path('private');rid='apply-linux-20261003T090004Z';now=datetime.datetime.now(datetime.timezone.utc).isoformat();runpath=root/'runs'/f'{rid}.json';run=json.loads(runpath.read_text())
assert json.loads((root/'runs/apply-active.lock').read_text())['run_id']==rid
for p in (root/'runs').glob('*.json'):
 d=json.loads(p.read_text())
 if d.get('status') in ['running','in_progress'] and d.get('run_id')!=rid:raise RuntimeError('Concurrent writer '+str(p))
original=(root/'applications.csv').read_bytes();rows=list(csv.DictReader((root/'applications.csv').open()));fields=list(rows[0]);events=[];changed=[]
resume=json.loads((root/'resumes.json').read_text())['resumes'][1];assert hashlib.sha256(Path(resume['path']).read_bytes()).hexdigest()==resume['sha256']
profile=json.loads((root/'profile.json').read_text())
jobs=[('Graphcore','Firmware Engineering Intern','8842203002','graphcore-early-careers','Austin, Texas, United States','blocked','browser_destination_data_approval_required','Approve sharing email, phone, approved May 2028 resume text and truthful work-status/sponsorship information with Graphcore via Greenhouse; no private data entered.'),('Formlabs','Embedded Software Intern (Summer 2027)','8222268','formlabsinternships','Somerville, MA','blocked','duplicate_identity_unresolved; personal_answer_and_portfolio_missing','Reconcile generic Sept 10 Formlabs receipt against employer history before applying; user must supply favorite C++ feature and portfolio; clarify winter/spring wording on the summer form.')]
for company,role,req,tenant,location,status,blocker,next_action in jobs:
 assert not any(r['company']==company and r['requisition_id']==req for r in rows)
 aid='APP-'+hashlib.sha256((company.lower()+'|'+req).encode()).hexdigest()[:12];folder=root/'applications'/aid;folder.mkdir(exist_ok=True)
 url=f'https://job-boards.greenhouse.io/{tenant}/jobs/{req}'
 cp={'application_id':aid,'company':company,'role':role,'requisition_id':req,'url':url,'captured_at':now,'last_completed_step':'Public posting and employer form inspected; only first/last name entered' if company=='Graphcore' else 'Public form inspected; no data entered','resume_id':resume['id'],'resume_sha256':resume['sha256'],'resume_delivery':'not_yet_delivered','submission_attempted':False,'blocker':blocker,'next_action':next_action,'verified_answers_already_used':{'First Name':'Khanh','Last Name':'Nguyen'} if company=='Graphcore' else {},'expected_graduation_month':'2028-05'}
 (folder/'resume-checkpoint.json').write_text(json.dumps(cp,indent=2)+'\n');(folder/'resume-checkpoint.json').chmod(384)
 if company=='Graphcore':
  text=Path('work/intern-2028-verified.txt').read_text().replace('\f','');assert 'May 2028' in text
  (folder/'approved-resume-text.txt').write_text(text);(folder/'approved-resume-text.txt').chmod(384)
  prepared={'email':profile['contact']['email'],'phone':profile['contact']['phone_e164'],'linkedin':profile['contact']['linkedin_url'],'right_to_work_answer':'Yes','right_to_work_details':'F-1 student; OPT not yet requested; no current EAD; employer sponsorship now or in the future required.','optional_disclosures':'Leave unanswered','source_resume_sha256':resume['sha256'],'not_transmitted':True}
  (folder/'prepared-answers.json').write_text(json.dumps(prepared,indent=2)+'\n');(folder/'prepared-answers.json').chmod(384)
 r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,job_type='internship',location=location,country='US',ats='Greenhouse',ats_tenant=tenant,requisition_id=req,apply_url=url,canonical_url=url,discovered_at=now,status=status,resume_id=resume['id'],resume_sha256=resume['sha256'],last_action_at=now,evidence_path=str(folder/'resume-checkpoint.json'),blocker=blocker,next_action=next_action,submission_source='bot',status_updated_at=now,notes='No submit attempted; no private contact, resume or immigration information sent.');rows.append(r);changed.append(aid)
 events.append({'timestamp':now,'application_id':aid,'event':'application_blocked','new_status':status,'reason':blocker,'evidence_path':r['evidence_path'],'run_id':rid})
obs=json.loads(Path('work/apply-linux-20261003T090004Z/duplicate-observations.json').read_text());state=json.loads((root/'gmail-sync-state.json').read_text());review=json.loads((root/'gmail-review.json').read_text());decisions=[]
for m in obs:
 if m['id'] in state['processed_message_ids']:continue
 rec={'mailbox':state['mailbox'],'message_id':m['id'],'thread_id':m['thread'],'received_at':m['date'],'from':m['sender'],'subject':m['subject'],'excerpt':m['body'],'gmail_url':'https://mail.google.com/mail/u/0/#all/'+m['id'],'processed_at':now,'historical':True}
 if 'Verkada' in m['subject']:
  company='Verkada';role='Embedded Software Engineering Intern 2027';aid='APP-'+hashlib.sha256((company.lower()+'|'+role.lower()).encode()).hexdigest()[:12];assert not any(r['application_id']==aid for r in rows)
  rec.update(application_id=aid,company=company,role=role,decision='matched',status='applied',match_strength='unique_employer_exact_role_cycle')
  folder=root/'applications'/aid;folder.mkdir(exist_ok=True);f=folder/f'email-{m["id"]}.json';f.write_text(json.dumps(rec,indent=2)+'\n');f.chmod(384)
  r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,job_type='internship',status='applied',submission_source='external_unknown',discovered_at=now,applied_at=m['date'],status_updated_at=m['date'],last_email_at=m['date'],gmail_thread_ids=m['thread'],last_action_at=now,confirmation_url=rec['gmail_url'],evidence_path=str(f),notes='Historical employer receipt; requisition and submitted resume unknown. Do not resubmit matching internship.');rows.append(r);changed.append(aid)
  events.append({'timestamp':now,'application_id':aid,'event':'gmail_application_reconciled','new_status':'applied','historical':True,'message_id':m['id'],'evidence_path':str(f),'run_id':rid})
 else:
  rec.update(decision='needs_review',review_reason='Generic Formlabs receipt does not identify role or requisition. Employer history required before applying to 8222268.',user_action_required=True)
  if not any(x.get('message_id')==m['id'] for x in review['items']):review['items'].append(rec)
 decisions.append(rec);state['processed_message_ids'].append(m['id'])
assert (root/'applications.csv').read_bytes()==original
p=root/'applications.csv';tmp=p.with_suffix('.tmp')
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
assert len(list(csv.DictReader(tmp.open())))==174;tmp.chmod(384);os.replace(tmp,p)
for name,items in [('events.jsonl',events),('gmail-messages.jsonl',decisions)]:
 with (root/name).open('a') as f:
  for item in items:f.write(json.dumps(item)+'\n')
for p,d in [(root/'gmail-sync-state.json',state),(root/'gmail-review.json',review)]:p.write_text(json.dumps(d,indent=2)+'\n');p.chmod(384)
run.update(counters={'confirmed_new':0,'blocked':2,'skipped':0,'duplicates_avoided':3,'historical_receipts_imported':1,'submission_unknown':0},changed_application_ids=changed,tracker_rows=174,source_cursors={'greenhouse':'Graphcore intern awaiting destination/data approval','worldwide_search':'North America, Europe, Southeast Asia and Oceania queried; MediaTek MTK120260731012, WSA 7956043 and HPE 1213618 are unverified leads for later eligibility checks. Remaining regions not yet searched.'},mandatory_handoff='Browser tool requires specific destination and private-data approval; request pending for Graphcore 8842203002.',browser_tab_id='1988269728')
runpath.write_text(json.dumps(run,indent=2)+'\n');runpath.chmod(384)
p=Path('work/apply-linux-20261003T090004Z/excel-source.json');p.write_text(json.dumps(rows));p.chmod(384)
print(json.dumps(run['counters']))
