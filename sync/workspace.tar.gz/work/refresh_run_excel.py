import csv,copy,datetime,os,tempfile
from pathlib import Path
import openpyxl
from openpyxl.utils.cell import get_column_letter
root=Path('/home/nkhanh/khanh-dev/mass-apply');p=root/'private/applications.xlsx'; rows=list(csv.DictReader((root/'private/applications.csv').open(newline='')));w=openpyxl.load_workbook(p);s=w['Applications'];table=s.tables['ApplicationsTable'];heads=[s.cell(4,j).value for j in range(1,s.max_column+1)];cols=[h.replace(' ','_') for h in heads];idcol=cols.index('application_id')+1;known={s.cell(i,idcol).value for i in range(5,s.max_row+1)};assert len(known)==s.max_row-4
changed=[]
for r in rows:
 if r['application_id'] in known:continue
 rownum=s.max_row+1
 for j,k in enumerate(cols,1):
  source=s.cell(5,j);target=s.cell(rownum,j);target._style=copy.copy(source._style);target.alignment=copy.copy(source.alignment)
  v=r.get(k,'')
  if k in {'posted_at','discovered_at','last_action_at','applied_at','last_email_at','status_updated_at','action_due_at'} and v:
   d=datetime.datetime.fromisoformat(v.replace('Z','+00:00'));v=d.astimezone(datetime.timezone(datetime.timedelta(hours=-4))).replace(tzinfo=None)
  target.value=v or None
 s.row_dimensions[rownum].height=65;changed.append(r['application_id'])
table.ref=f'A4:{get_column_letter(len(cols))}{s.max_row}'
assert s.max_row-4==len(rows)
fd,tmp=tempfile.mkstemp(dir=p.parent,suffix='.xlsx');os.close(fd);w.save(tmp);os.chmod(tmp,0o600);check=openpyxl.load_workbook(tmp,read_only=True);sh=check['Applications'];idx={sh.cell(i,idcol).value:i for i in range(5,sh.max_row+1)}
for aid in changed:
 i=idx[aid];assert sh.cell(i,cols.index('status')+1).value=='blocked'
assert check['Email Log'].max_row==w['Email Log'].max_row
check.close();os.replace(tmp,p);print({'added':changed,'rows':len(rows),'email_log_rows':w['Email Log'].max_row})
