from pathlib import Path
import csv, json, datetime, hashlib, zipfile, xml.etree.ElementTree as ET

root=Path('private'); run_id='gmail-linux-20261003T080204Z'
run_path=root/'runs'/f'{run_id}.json'; run=json.loads(run_path.read_text())
lock=root/'runs/gmail-sync-active.lock'
assert json.loads(lock.read_text())['run_id']==run_id
rows=list(csv.DictReader((root/'applications.csv').open()))
assert len(rows)==171 and len({r['application_id'] for r in rows})==171
# Verify the saved workbook, not just the in-memory representation.
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(root/'applications.xlsx') as z:
 strings=[]
 if 'xl/sharedStrings.xml' in z.namelist():
  strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
 sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
 cells={}
 for c in sheet.findall('.//m:sheetData/m:row/m:c',ns):
  v=c.find('m:v',ns)
  text=(v.text or '') if v is not None else ''.join(c.find('m:is',ns).itertext()) if c.find('m:is',ns) is not None else ''
  if c.attrib.get('t')=='s':text=strings[int(text)]
  cells[c.attrib['r']]=text
 ids={v for v in cells.values() if v.startswith('APP-')}
 assert ids=={r['application_id'] for r in rows},'Saved workbook ID mismatch'
 for r in rows:
  idcell=next(k for k,v in cells.items() if v==r['application_id'])
  rownum=''.join(x for x in idcell if x.isdigit())
  assert cells.get('C'+rownum)==r['status'],r['application_id']
for aid in ['APP-921719707985','APP-90d94343661e']:
 r=next(r for r in rows if r['application_id']==aid)
 assert r['status']=='applied' and r['resume_sha256'] and r['confirmation_url'].endswith('/confirmation')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
query='in:anywhere -in:trash after:2026/09/29 before:2026/10/04 {application interview assessment "thank you for applying" "next steps" "job offer" "not selected" "moving forward" from:myworkday.com from:greenhouse-mail.io from:lever.co from:ashbyhq.com from:smartrecruiters.com from:icims.com from:jobs.nvidia.com from:workday.com}'
state_path=root/'gmail-sync-state.json'; state=json.loads(state_path.read_text())
state['last_incremental_query']=query
state['last_incremental_scan_count']=67
state['last_incremental_run_at']=run['started_at']
state['last_run']={'run_id':run_id,'started_at':run['started_at'],'completed_at':now,'connector':'Composio Gmail','account_verified':state['mailbox'],'incremental_scanned':67,'incremental_new_decisions':13,'backfill_page_processed':25,'backfill_pending':75,'historical_backfill_complete':False,'historical_next_page_saved':True,'applications_created':28,'tracker_rows':171,'workbook_verified':True}
events=[json.loads(s) for s in (root/'events.jsonl').read_text().splitlines() if s]
new_events=[e for e in events if e.get('run_id')==run_id and e.get('event') in ['gmail_application_reconciled','reference_letter_required']]
notified=set(state.get('notified_event_ids',[]))
notified.update(e['event_id'] for e in new_events)
state['notified_event_ids']=sorted(notified)
state_path.write_text(json.dumps(state,indent=2)+'\n');state_path.chmod(0o600)
run.update(status='completed_incremental_backfill_partial',completed_at=now,incremental_query=query,tracker_rows=171,workbook_verified=True,backfill_pending_count=75,backfill_next_page_token=state['backfill']['pending_next_page_token'],stop_reason='Incremental scan complete. Historical page partially processed with exact 75 pending IDs and page cursors saved for the next scheduled run.')
run_path.write_text(json.dumps(run,indent=2)+'\n');run_path.chmod(0o600)
with (root/'events.jsonl').open('a') as f:
 f.write(json.dumps({'timestamp':now,'event':'gmail_sync_completed','run_id':run_id,'incremental_complete':True,'backfill_complete':False,'tracker_rows':171,'workbook_verified':True})+'\n')
for p in Path('work/gmail-linux-20261003T080204Z').glob('*.json'):p.chmod(0o600)
assert json.loads(lock.read_text())['run_id']==run_id
lock.unlink()
print(json.dumps({'tracker_rows':171,'workbook_verified':True,'incremental_complete':True,'historical_backfill_complete':False,'lock_released':True}))
