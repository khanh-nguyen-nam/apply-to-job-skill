from pathlib import Path
import csv,json,datetime,hashlib,os
root=Path('private');now=datetime.datetime.now(datetime.timezone.utc).isoformat();work=Path('work/gmail-linux-20261002T200133Z');runid='gmail-linux-20261002T200133Z'
rows=list(csv.DictReader((root/'applications.csv').open()));fields=list(rows[0]);state=json.loads((root/'gmail-sync-state.json').read_text());review=json.loads((root/'gmail-review.json').read_text());processed=set(state['processed_message_ids']);decisions=[];events=[];changed=[];new=[]
# Evidence-derived role identities; never match by shared thread.
specs={
'1a0fe2f3510709c4':('Microsoft','Software Engineer: Security & Identity Intern Opportunities for University Students, Redmond','200042199','applied'),
'1a0fe2e1c2943ddd':('Microsoft','Research Intern - Security Research Group, Microsoft Research Redmond','200059346','applied'),
'1a0fe2c6e859c33b':('Amazon','Software Dev Engineer (ED), Amazon Devices - Ring & Blink','10511802','applied'),
'1a0fe288907bbe58':('Amazon','Firmware Engineer II','10530521','applied'),
'1a0fe273a1e10f8e':('Amazon','Embedded Software Dev Engineer, AWS Hardware Engineering','10556875','applied'),
'1a0fe2a0dfe599ff':('Amazon','Robotics - Hardware Development Engineer Intern/Co-op - 2026 (Robotics, Mechanical, Electrical, Hardware Test, Reliability, Failure Analysis, Operations, and more)','3145033','withdrawn'),
'1a0fe1e1220c42fa':('SK hynix memory solutions America Inc.','SSD Firmware Development Engineer Intern','','applied'),
'1a0fe1cf00a22128':('Relay','Software Engineering Intern (Device Team) - Summer 2027','','applied'),
'1a0fdea606e82ae0':('Philips','Intern – Embedded Systems Test Automation Engineer – Bothell, WA – Summer 2027','592074','rejected'),
'1a0f43e7f647d8ec':('WHOOP','Embedded Systems Co-op','','rejected')}
for m in json.loads((work/'new-observations.json').read_text()):
 mid=m['id']
 if mid in processed:continue
 rec={'mailbox':state['mailbox'],'message_id':mid,'thread_id':m['thread'],'received_at':m['date'],'from':m['sender'],'subject':m['subject'],'gmail_url':'https://mail.google.com/mail/u/0/#all/'+mid,'excerpt':m['body'][:650],'processed_at':now}
 if mid in specs:
  company,role,req,status=specs[mid];matches=[r for r in rows if r['company'].casefold()==company.casefold() and ((req and r['requisition_id']==req) or (not req and r['role']==role))]
  if len(matches)>1:raise RuntimeError('Ambiguous identity '+mid)
  if not matches:
   aid='APP-'+hashlib.sha256((company.casefold()+'|'+(req or role.casefold())).encode()).hexdigest()[:12];assert not any(r['application_id']==aid for r in rows)
   r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,requisition_id=req,status=status,submission_source='external_unknown',discovered_at=now,job_type='internship' if 'intern' in role.lower() or 'co-op' in role.lower() else '',applied_at=m['date'] if status=='applied' else '',status_updated_at=m['date']);rows.append(r);new.append(aid);prior=None
  else:r=matches[0];aid=r['application_id'];prior=r['status']
  dated=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
  if not r['status_updated_at'] or dated(m['date'])>=dated(r['status_updated_at']):r['status']=status;r['status_updated_at']=m['date']
  if not r['applied_at'] and status=='applied':r['applied_at']=m['date']
  tids=set(filter(None,r['gmail_thread_ids'].split(';')));tids.add(m['thread']);r['gmail_thread_ids']=';'.join(sorted(tids));r['last_email_at']=max(filter(None,[r['last_email_at'],m['date']]),key=dated);r['last_action_at']=now
  rec.update(application_id=aid,company=company,role=role,requisition_id=req,decision='matched',status=status,match_strength='employer_and_requisition' if req else 'unique_employer_exact_role')
  artifact=root/'applications'/aid;artifact.mkdir(exist_ok=True);evidence=artifact/f'email-{mid}.json';evidence.write_text(json.dumps(rec,indent=2)+'\n');evidence.chmod(0o600)
  if not r['evidence_path'] or prior!=r['status']:r['evidence_path']=str(evidence)
  if not r['confirmation_url'] and status=='applied':r['confirmation_url']=rec['gmail_url']
  r['next_action']='Monitor employer response' if status=='applied' else '';changed.append(aid)
  events.append({'timestamp':now,'application_id':aid,'event':'gmail_application_reconciled','prior_status':prior,'new_status':r['status'],'message_id':mid,'event_at':m['date'],'evidence_path':str(evidence),'historical':m['date']<'2026-10-02T00:00:00Z'})
 elif mid in ['1a0fe2ac0a49f826','1a0fe23fc774ba95','1a0fe22e981ec9bc']:
  rec.update(decision='informational',excerpt='Conditional application-progress notice; not proof of submission. Separate explicit receipt reconciled by requisition.')
 else:
  rec.update(decision='needs_review',review_reason='Generic Astera receipt lacks role/requisition; both same-day Astera applications are already employer-confirmed. Preserve unassigned receipt rather than guess job identity.',user_action_required=False)
  if not any(x.get('message_id')==mid for x in review['items']):review['items'].append(rec)
 decisions.append(rec);processed.add(mid)
notice='1a0f5338fc964e14'
if notice not in processed:decisions.append({'mailbox':state['mailbox'],'message_id':notice,'received_at':'2026-10-01T02:03:11Z','subject':'Verify your candidate account','decision':'irrelevant','excerpt':'Candidate-account verification notice; not an application status event. Activation link omitted.','processed_at':now});processed.add(notice)
# Re-read just before atomic commit; defer if any competing run has started.
for p in (root/'runs').glob('*.json'):
 d=json.loads(p.read_text())
 if d.get('status') in ['in_progress','running'] and d.get('run_id')!=runid:raise RuntimeError('Concurrent writer run '+p.name)
current=list(csv.DictReader((root/'applications.csv').open()));assert {r['application_id'] for r in current}.issubset({r['application_id'] for r in rows})
p=root/'applications.csv';tmp=p.with_suffix('.tmp')
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
assert len(list(csv.DictReader(tmp.open())))==len(rows);tmp.chmod(0o600);os.replace(tmp,p)
for filename,data in [('events.jsonl',events),('gmail-messages.jsonl',decisions)]:
 with (root/filename).open('a') as f:
  for x in data:f.write(json.dumps(x)+'\n')
(root/'gmail-review.json').write_text(json.dumps(review,indent=2)+'\n')
state['processed_message_ids']=sorted(processed);state['last_incremental_completed_at']='2026-10-02T20:02:32.034930+00:00';state['incremental_pending']=None;state['last_incremental_query']='in:anywhere -in:trash after:2026/09/29 before:2026/10/03 application/recruiting terms and known ATS senders';(root/'gmail-sync-state.json').write_text(json.dumps(state,indent=2)+'\n')
run=root/'runs'/f'{runid}.json';d=json.loads(run.read_text());d.update(incremental_scan_count=54,incremental_new_decisions=len(decisions),new_application_ids=new,changed_application_ids=sorted(set(changed)),incremental_complete=True);run.write_text(json.dumps(d,indent=2)+'\n')
for p in [root/'gmail-review.json',root/'gmail-sync-state.json',run]:p.chmod(0o600)
print(json.dumps({'new_records':len(new),'changed_rows':len(set(changed)),'decisions':len(decisions),'tracker_rows':len(rows),'incremental_complete':True}))
