from pathlib import Path
import csv,json,datetime,hashlib,os
root=Path('private');now=datetime.datetime.now(datetime.timezone.utc).isoformat();work=Path('work/gmail-linux-20261002T200133Z');runid='gmail-linux-20261002T200133Z'
rows=list(csv.DictReader((root/'applications.csv').open()));fields=list(rows[0]);state=json.loads((root/'gmail-sync-state.json').read_text());review=json.loads((root/'gmail-review.json').read_text());processed=set(state['processed_message_ids']);decisions=[];events=[];changed=[];new=[]
import re
specs={
'1a0c22838ba87093':('Seagate','Embedded Software Engineering Intern','14748','applied'),
'1a0c22741275fa3b':('Seagate','R&D Firmware and Software Engineering Test Developer - Internship','14937','applied'),
'1a0c225b2c7945c3':('Seagate','Test Process & Engineer Firmware Intern','14442','applied'),
'1a0baf7ea762fe7d':('Cirrus Logic','Embedded Audio Firmware Engineer','','applied'),
'1a0baf5dc8b97734':('Cirrus Logic','Embedded Software Engineer (LDN)','','applied'),
'1a0baeeb6100df36':('Vermeer Corporation','Embedded Software Engineer Internship Summer 2027 (Evergreen)','REQ-22165','applied'),
'1a0bae74809402ac':('WHOOP','Embedded Systems Co-op','','applied'),
'1a0b6e76e99ccba7':('Kamstrup','Internship in Embedded Software Development for Electricity Meters','','applied'),
'1a0b69da8770d3f9':('Broadcom','Firmware Engineer 2','R026980','rejected'),
'1a0b635692250f43':('Punch Through Design LLC','Embedded Software Engineer Intern (Hybrid)','','applied'),
'1a0b6245514bf57f':('Blissway','Embedded Systems Engineer, Recent Graduate','','interview'),
'1a0b53d896926e90':('Rivian','Early Career - HIL Engineer II, Charging and Energy','','applied'),
'1a0b280f84111ad0':('NXP','Embedded Machine Learning & Radar Processing Intern - Summer 2027','','applied'),
'1a0b184f71e282ac':('Snap Inc.','Software Engineer, Device Security, Level 4','','closed'),
'1a0b137365a7c380':('SK hynix memory solutions America Inc.','SSD Firmware Development Engineer Intern','','rejected'),
'1a0ab4732eadf121':('Neurophos','Firmware Engineer','','rejected'),
'1a0ab385fdced43f':('Qualcomm','2026 Intern-Embedded SW Engineer(SOC)','3087394','applied'),
'1a0ab088e040ae18':('Broadcom','Firmware Engineer - Fibre Channel/NVME Networked-Storage','R027013','rejected'),
'1a0aa69472a0574a':('EquipmentShare','Intern: Engineering (Embedded)','','rejected'),
'1a0a928ee7bbe0ec':('Allegion','Summer Intern - Firmware Engineer','','applied'),
'1a0a928dbc6b345d':('Allegion','Summer Intern – Firmware Engineer (Advanced Development) – Indianapolis, IN','','applied'),
'1a0a928d87257d00':('Allegion','Systems Test Engineer','','applied'),
'1a0a86d75ec2df2f':('Shure','Electrical Engineering Intern (Digital Circuitry & Test Automation)','','applied'),
'1a0a86d094a3a347':('Shure','Embedded Systems Development Engineer','','applied')}
observations=json.loads((work/'backfill-observations.json').read_text())
for m in observations:
 if m['sender']=='Tesla <noreply@tesla.com>':
  q=re.search(r'submitting your application for the (.+), (\d+) position',m['body']);assert q;specs[m['id']]=('Tesla',q[1].strip(),q[2],'applied')
 elif m['sender'].startswith('Zoox '):
  q=re.search(r'received your application to (.+?)\. Thank you',m['body']);assert q;specs[m['id']]=('Zoox',q[1],'','applied')
 elif '(CNH)' in m['sender']:
  role=m['subject'].split('application for ')[1].replace('\u200b','').strip();specs[m['id']]=('CNH',role,'','applied')
for m in observations:
 mid=m['id']
 if mid in processed:continue
 rec={'mailbox':state['mailbox'],'message_id':mid,'thread_id':m['thread'],'received_at':m['date'],'from':m['sender'],'subject':m['subject'],'gmail_url':'https://mail.google.com/mail/u/0/#all/'+mid,'excerpt':m['body'][:650],'processed_at':now}
 if mid in specs:
  company,role,req,status=specs[mid];matches=[r for r in rows if r['company'].casefold()==company.casefold() and ((req and r['requisition_id']==req) or (not req and r['role']==role))]
  if len(matches)>1:raise RuntimeError('Ambiguous identity '+mid)
  if not matches:
   aid='APP-'+hashlib.sha256((company.casefold()+'|'+(req or role.casefold())).encode()).hexdigest()[:12];assert not any(r['application_id']==aid for r in rows)
   r={k:'' for k in fields};r.update(application_id=aid,company=company,role=role,requisition_id=req,status=status,submission_source='external_unknown',discovered_at=now,job_type='internship' if 'intern' in role.lower() or 'co-op' in role.lower() else '',applied_at=m['date'] if status=='applied' else '',status_updated_at=m['date']);rows.append(r);new.append(aid);prior=None
  else:r=matches[0];aid=r['application_id'];prior=r['status']
  dated=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
  if not r['status_updated_at'] or dated(m['date'])>=dated(r['status_updated_at']):r['status']=status;r['status_updated_at']=m['date']
  if status=='applied' and (not r['applied_at'] or dated(m['date'])<dated(r['applied_at'])):r['applied_at']=m['date']
  tids=set(filter(None,r['gmail_thread_ids'].split(';')));tids.add(m['thread']);r['gmail_thread_ids']=';'.join(sorted(tids));r['last_email_at']=max(filter(None,[r['last_email_at'],m['date']]),key=dated);r['last_action_at']=now
  rec.update(application_id=aid,company=company,role=role,requisition_id=req,decision='matched',status=status,match_strength='employer_and_requisition' if req else 'unique_employer_exact_role')
  artifact=root/'applications'/aid;artifact.mkdir(exist_ok=True);evidence=artifact/f'email-{mid}.json';evidence.write_text(json.dumps(rec,indent=2)+'\n');evidence.chmod(0o600)
  if not r['evidence_path'] or prior!=r['status']:r['evidence_path']=str(evidence)
  if not r['confirmation_url'] and status=='applied':r['confirmation_url']=rec['gmail_url']
  if prior is None or prior==r['status']:r['next_action']='Monitor employer response' if r['status']=='applied' else ''
  if mid=='1a0b6245514bf57f':r['notes']='Historical interview scheduled September24,2026 at17:00EDT; completion unverified; not a newly scheduled interview today.';changed.append(aid)
  events.append({'timestamp':now,'application_id':aid,'event':'gmail_application_reconciled','prior_status':prior,'new_status':r['status'],'message_id':mid,'event_at':m['date'],'evidence_path':str(evidence),'historical':m['date']<'2026-10-02T00:00:00Z'})
 elif mid in ['1a0fe2ac0a49f826','1a0fe23fc774ba95','1a0fe22e981ec9bc']:
  rec.update(decision='informational',excerpt='Conditional application-progress notice; not proof of submission. Separate explicit receipt reconciled by requisition.')
 else:
  rec.update(decision='needs_review',review_reason='Historical message has no unique role/requisition, is an incomplete-application notice, or contains an ambiguous generic invitation. Preserve evidence for later matching; do not guess.',user_action_required=False)
  if not any(x.get('message_id')==mid for x in review['items']):review['items'].append(rec)
 decisions.append(rec);processed.add(mid)
# Re-read just before atomic commit; defer if any competing run has started.
for p in (root/'runs').glob('*.json'):
 d=json.loads(p.read_text())
 if d.get('status') in ['in_progress','running'] and d.get('run_id')!=runid:raise RuntimeError('Concurrent writer run '+p.name)
current=list(csv.DictReader((root/'applications.csv').open()));assert {r['application_id'] for r in current}.issubset({r['application_id'] for r in rows})
p=root/'applications.csv';tmp=p.with_suffix('.tmp')
with tmp.open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
assert len(list(csv.DictReader(tmp.open())))==len(rows);tmp.chmod(0o600);os.replace(tmp,p)
for filename,data in [('events.jsonl',events),('gmail-messages.jsonl',decisions)]:
 with (root/filename).open('a') as f:
  for x in data:f.write(json.dumps(x)+'\n')
(root/'gmail-review.json').write_text(json.dumps(review,indent=2)+'\n')
state['processed_message_ids']=sorted(processed);state['backfill']['pending_message_ids']=[x for x in state['backfill']['pending_message_ids'] if x not in processed];state['backfill']['messages_processed']+=len(decisions);state['backfill']['oldest_processed_at']=min(x['date'] for x in observations);state['backfill']['next_page_token']=state['backfill'].get('pending_next_page_token');state['backfill']['note']='Saved pending page fully classified. Resume next_page_token; historical scan remains incomplete.';(root/'gmail-sync-state.json').write_text(json.dumps(state,indent=2)+'\n')
run=root/'runs'/f'{runid}.json';d=json.loads(run.read_text());d.update(backfill_new_decisions=len(decisions),backfill_new_application_ids=new,backfill_changed_application_ids=sorted(set(changed)),backfill_complete=False);run.write_text(json.dumps(d,indent=2)+'\n')
for p in [root/'gmail-review.json',root/'gmail-sync-state.json',run]:p.chmod(0o600)
print(json.dumps({'new_records':len(new),'changed_rows':len(set(changed)),'decisions':len(decisions),'tracker_rows':len(rows),'backfill_complete':False}))
