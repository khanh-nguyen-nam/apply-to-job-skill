# Current application workflow — October 4, 2026

Use Jobright for job discovery and Apply with Autofill. Active market: United States; firmware, embedded, kernel, Linux and systems internships/new-grad roles. Approved resumes: May 2027 new-grad and May 2028 internship. Use current private/preferences.json and AGENTS.md; the notes below are historical where they conflict.

Daily Linux run: 5 AM Indianapolis time, maximum five hours, no fixed application count. Model: GPT-6 Sol with Low reasoning. Automatic authorized submissions continue without routine review. Record individual blockers and continue.

Recurring Gmail status sync is disabled. The final October 4 snapshot is complete: 371 application records, with an Email Log in private/applications.xlsx. Track from the local sheet/canonical records. New mailbox outcomes and manual external applications are not imported automatically. Gmail may still retrieve narrowly matched transient sign-in codes and account activation links after authorized employer signup; never save codes or tokenized links.

GitHub Mac sync: the user has authorized a filtered personal workspace snapshot in the existing private apply-to-job-skill repository. See that repository's sync/README.md. Preserve destination-only/newer Mac changes before restoring. Linux automation exports are reference files only; do not activate duplicate Mac schedules.

---

## Historical setup notes

# Jobright application setup

Your skill is in [skills/apply-to-job/SKILL.md](skills/apply-to-job/SKILL.md).

Your current resume PDFs and editable LaTeX sources are in **`private/resumes/`**. The workflow selects the May 2027 PDF for new-grad roles and the May 2028 PDF for internships. Updating a local file does not automatically upload it, start a job search, or submit applications.

Your requested default is automatic submission once setup is ready and you start an apply run. No routine per-job approval is required for that authorized run. Missing facts, login requirements, and exceptional tool-required confirmations are recorded as blockers so other applications can continue.

For Mac/Linux file transfer, see [SYNC-PRIVATE.md](SYNC-PRIVATE.md). Shared records use relative paths; the latest saved authorization and preferences supersede older setup observations below.

## Finish setup

1. Your saved U.S. work-authorization answer is Yes, as you explicitly confirmed; future sponsorship remains Yes. F-1 status, no current EAD, and OPT not yet requested remain separately recorded facts.
2. You confirmed returning to school after internship on 2026-10-02; verify other enrollment eligibility if a form asks for it.
3. The official [Jobright Autofill extension](https://chromewebstore.google.com/detail/odcnpipkhjegpefkfplmedhmkmmhmoko) is now visible in Chrome's Extensions menu, and Jobright shows its enablement step completed.
4. Jobright shows `resume_khanh_fulltime` as its Primary resume and `Khanh Nguyen - Internship - May 2028` as a second uploaded resume. Choose the resume that matches the role; the Jobright profile itself currently displays May 2027. Work authorization and voluntary disclosures shown in Jobright have not been reconfirmed. Autofill on an employer form has not yet been tested.
5. Start with a defined application list or filters and a run limit. For example: “Use $apply-to-job to apply to these five job links using my approved resume.”

## Your files

The saved geographic target is **worldwide, including India**, including remote roles where you meet the employment-location requirements.

## Run or test the skill

Type these prompts in this Codex chat; no terminal command is needed:

- Test: “Use $apply-to-job to test one matching application without submitting.”
- Find jobs: “Use $apply-to-job to find 20 matching jobs worldwide, including India.”
- Apply: “Use $apply-to-job to apply to up to 5 eligible jobs from my tracker.”

A test checks local resume integrity, duplicate evidence, a live employer form, and missing answers. Record exactly which stages passed. A read-only check or local draft does not verify Jobright Autofill, file upload, or submission. Resolve stale Jobright answers before testing Autofill. Test mode never clicks Submit.

## Job sources

Worldwide discovery uses `private/job-boards.json`: Jobright and LinkedIn browser sessions, plus public FirmwareJobs, Gradcracker, EURES, SEEK, Jobstreet and employer career sites. Indeed is pending your review of its updated terms. Jobright covers six country choices, so other boards fill geographic gaps. LinkedIn's saved homepage location remains U.S.-only; the workflow searches explicit destinations. This is on-demand discovery; the 12-hour Gmail sync continues separately.

The authorized apply workflow is scheduled every day at **5:00 AM America/Indiana/Indianapolis** and stops after five hours or earlier if execution/account usage becomes unavailable. The active execution host is Linux, with a target of 10 new employer-confirmed submissions per daily run. The skill uses the available native sleep inhibitor during the run (Linux `systemd-inhibit` or Mac `caffeinate`); no third-party auto-clicker is installed. Each application error is recorded in `private/applications.csv` with its blocker, next action, evidence, and a resumable form checkpoint. CAPTCHA, non-email MFA, login recovery, and similar interruptions are saved as user handoffs; the relevant browser tab is kept open when supported, but the checkpoint allows safe reopening and refilling if the site session expires.

- `private/profile.json`: personal information and confirmation state.
- `private/answers.json`: reusable application answers.
- `private/preferences.json`: job filters and submission settings.
- `private/credentials.json`: account and password-manager references, with a new entry for each employer account when needed. Keep actual passwords in your browser/password manager.
- `private/resumes/` and `private/resumes.json`: local resume PDFs, LaTeX sources, and role-specific version index.
- `private/applications.csv`: application status tracker, including Gmail-imported manual applications.
- `private/applications/`: per-application answers, posting, and confirmation evidence.
- `private/events.jsonl` and `private/runs/`: change history and run summaries.
- `private/jobright.json`: verified connection and extension setup state.

The `private/` directory is excluded from Git and restricted to your local user. It is not encrypted. The skill archive contains only reusable instructions, not your personal data. No applications have been submitted by this setup. Gmail status monitoring was added afterward, as described below.

## Gmail tracking

Gmail account **namkhanh052005@gmail.com** is connected and verified. The **Sync Gmail job applications** 12-hour heartbeat reconciles application receipts and employer updates into `private/applications.csv`, covering bot and external/manual applications. It notifies you only about meaningful changes or needed action.

The initial pass reviewed 100 messages and imported 64 identified applications. Historical backfill for the last 90 days is still in progress. Thirty messages remain in `private/gmail-review.json` because they need stronger matching; these are messages, not 30 additional confirmed applications.

`private/gmail-sync.json` records the connection and automation ID; `private/gmail-sync-state.json` stores sync progress; `private/gmail-messages.jsonl` records evidence decisions. Gmail is read-only for this workflow. The shared local tracker is synchronized, not Jobright's separate tracker. Manual applications without email receipts need a manual entry or employer-history check.

To sync immediately, say: **“Use $apply-to-job to sync my Gmail application updates now.”**

## Composio

The Composio plugin is now part of the workflow for supported external services. Its Gmail connection is active and verified for **namkhanh052005@gmail.com**, and it is the preferred Gmail surface. The skill verifies the requested capability and exact account before using it; Composio does not expand the permissions in `private/authorization.md`. Jobright and employer applications still use the browser workflow.

During an authorized Jobright or employer-portal sign-in/account-creation flow, the workflow may retrieve a matching email one-time code and enter it without storing or displaying the code. CAPTCHA, non-email MFA, password recovery, and ambiguous verification messages remain user handoffs. Connection state is kept in `private/composio.json`; OAuth secrets and authorization URLs are never stored there.
