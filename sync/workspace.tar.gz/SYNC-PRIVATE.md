# GitHub workspace snapshot update — October 4, 2026

The user now authorizes pushing the skill and filtered personal workspace to the existing private GitHub repository khanh-nguyen-nam/apply-to-job-skill for Mac synchronization. This supersedes the earlier SCP-only restriction below. The snapshot includes verified profile/preferences/authorization, resumes, CSV/Excel tracker, email decisions/evidence, application artifacts, run summaries, workspace instructions and supporting files. Never include browser sessions, passwords, tokens, active locks, dependency links or recursive sync backups. Follow the repository sync/README.md to stage and reconcile on Mac. Linux automation exports remain reference-only on Mac.

---

## Earlier SCP workflow (optional)

# Mac and Linux application workspace sync

The skill is a private Git repository. Run `git pull --ff-only` in `~/.codex/skills/apply-to-job` before editing, then commit and push. Pull on the other machine to receive the committed change. Both machines authenticate to GitHub separately.

Workspace files travel using SCP. Mac workspace: `/Users/macboookpro/khanh-dev/mass-apply`. Linux workspace: `/home/nkhanh/khanh-dev/mass-apply`. SSH destination: `nkhanh-linux`.

The 2026-10-02 reconciliation combined 92 application records, preserved the two Linux employer-confirmed submissions and corrected rejection, retained Mac Gmail backfill, and included the newer Linux user preferences. Shared resume/evidence paths are relative to the workspace. The Excel tracker is regenerated from the merged CSV. Schedules continue to run on Linux; copying schedule references does not create or enable a Mac schedule.

## Before switching machines

1. Finish and save current application/Gmail work. Use one writer at a time; do not copy while either machine is updating the tracker.
2. Fetch a snapshot of the destination first. Compare it with the source and reconcile any changes; SCP does not merge files. Preserve confirmed submissions, application IDs, event history, and destination-only evidence. Rebuild the existing Excel tracker when CSV records change.
3. Transfer the reconciled files with SCP to a staging directory, then install them after checking that the live workspace has not changed since the snapshot. Keep the original snapshots for recovery.
4. Verify SHA-256 hashes on both machines, record counts and resume hashes. Keep private files at mode `600` and directories at mode `700`.

Transfer `private/`, `AGENTS.md`, `START-HERE.md`, `.gitignore`, this document, and supporting `work/` and `dist/` files. Exclude `private/sync-backups/`, `.gmail-sync.lock`, `.DS_Store`, Python caches, `.git/`, and machine-specific dependency links. Never copy browser sessions or authentication secrets. The `private/credentials.json` file contains account references only.

For a snapshot, pack the workspace into a temporary owner-only archive, then use SCP to transport that archive. Inspect/reconcile the snapshot before restoring it. From the Mac:

```sh
MAC_WORKSPACE=/Users/macboookpro/khanh-dev/mass-apply
LINUX_WORKSPACE=/home/nkhanh/khanh-dev/mass-apply
SYNC_SNAPSHOT=$(mktemp -d)
chmod 700 "$SYNC_SNAPSHOT"
tar --exclude='private/sync-backups' --exclude='private/sync-incoming' --exclude='.gmail-sync.lock' \
    --exclude='.DS_Store' --exclude='__pycache__' --exclude='node_modules' \
    -czf "$SYNC_SNAPSHOT/workspace.tar.gz" -C "$MAC_WORKSPACE" \
    private AGENTS.md START-HERE.md .gitignore SYNC-PRIVATE.md work dist
chmod 600 "$SYNC_SNAPSHOT/workspace.tar.gz"
ssh nkhanh-linux 'umask 077; mkdir -p ~/khanh-dev/mass-apply/private/sync-incoming'
scp -p "$SYNC_SNAPSHOT/workspace.tar.gz" \
    nkhanh-linux:"$LINUX_WORKSPACE/private/sync-incoming/mac-workspace.tar.gz"
```

For the reverse direction, create the same filtered snapshot on Linux and retrieve it with `scp -p nkhanh-linux:/path/to/linux-workspace.tar.gz "$SYNC_SNAPSHOT/"`. Exclude `private/sync-incoming` from future archives as well. These commands create staging snapshots; they do not automatically overwrite the other machine's data.

The initial pre-sync snapshots and reconciliation evidence are under `private/sync-backups/20261002T190244Z/` on Mac and Linux. Keep these out of future transfer archives and all Git commits or skill packages. Both installations were checked by hash after SCP transfer: 176 shared files and 92 application records. Both skill checkouts are at Git commit `47fdd82`. See `private/sync-backups/20261002T190244Z/sync-status.json` for the completion checkpoint.
